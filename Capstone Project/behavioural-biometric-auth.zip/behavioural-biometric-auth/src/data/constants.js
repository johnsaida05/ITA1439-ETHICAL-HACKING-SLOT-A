/**
 * Project-wide constants.
 *
 * NOTE FOR THE VIVA: every number in this file is a *demo* constant chosen so
 * that the prototype produces believable output. Nothing here is trained from
 * real users - the "model" is the explainable weighted formula in
 * src/services/authService.js.
 */

export const APP_TITLE = 'Behavioural Biometric Authentication using AI';
export const APP_SHORT = 'BioAuth AI';
export const APP_VERSION = '1.0.0 (prototype)';

/** Demo login credentials. Front-end only check - no server, no hashing. */
export const DEMO_CREDENTIALS = {
  username: 'student',
  password: 'demo123',
};

/** Risk thresholds used by the whole app (Module 2 + Module 3). */
export const THRESHOLDS = {
  LOW_RISK_MIN: 70, // 70 - 100  -> Low risk / Authenticated
  MEDIUM_RISK_MIN: 40, // 40 - 69   -> Medium risk / Verification required
  // 0 - 39   -> High risk / Suspicious activity
};

/**
 * How far past the tolerance band a feature may drift before it scores 0.
 * Deviation <= tolerance        -> still "within tolerance", similarity > 0.5
 * Deviation == 2 x tolerance    -> similarity 0 (the feature contributes nothing)
 */
export const SIMILARITY_ZERO_MULTIPLIER = 2;

/**
 * The six behavioural features the simulated model uses.
 *
 * baseline  - the value a freshly generated profile centres on
 * tolerance - the accepted deviation band for this feature
 * weight    - the feature's importance in the model (all weights sum to 1.00)
 */
export const FEATURES = [
  {
    key: 'typingSpeed',
    label: 'Typing Speed',
    short: 'Typing speed',
    unit: 'WPM',
    group: 'Keystroke Dynamics',
    baseline: 48,
    tolerance: 14,
    weight: 0.2,
    decimals: 0,
    min: 8,
    max: 120,
  },
  {
    key: 'keyHoldTime',
    label: 'Avg Key Press Duration',
    short: 'Key hold time',
    unit: 'ms',
    group: 'Keystroke Dynamics',
    baseline: 96,
    tolerance: 28,
    weight: 0.18,
    decimals: 0,
    min: 30,
    max: 320,
  },
  {
    key: 'flightTime',
    label: 'Avg Flight Time (key to key)',
    short: 'Flight time',
    unit: 'ms',
    group: 'Keystroke Dynamics',
    baseline: 165,
    tolerance: 48,
    weight: 0.14,
    decimals: 0,
    min: 40,
    max: 700,
  },
  {
    key: 'mouseSpeed',
    label: 'Mouse Movement Speed',
    short: 'Mouse speed',
    unit: 'px/s',
    group: 'Mouse Movements',
    baseline: 420,
    tolerance: 130,
    weight: 0.16,
    decimals: 0,
    min: 20,
    max: 1800,
  },
  {
    key: 'clickRate',
    label: 'Click Rate',
    short: 'Click rate',
    unit: 'clicks/min',
    group: 'Click & Scroll Patterns',
    baseline: 22,
    tolerance: 9,
    weight: 0.16,
    decimals: 1,
    min: 0,
    max: 120,
  },
  {
    key: 'scrollRate',
    label: 'Scroll Rate',
    short: 'Scroll rate',
    unit: 'scrolls/min',
    group: 'Click & Scroll Patterns',
    baseline: 30,
    tolerance: 13,
    weight: 0.16,
    decimals: 1,
    min: 0,
    max: 200,
  },
];

export const FEATURE_MAP = FEATURES.reduce((acc, f) => {
  acc[f.key] = f;
  return acc;
}, {});

/** Names of the five pipeline stages shown in the UI (Module 2). */
export const PIPELINE_STAGES = [
  {
    id: 'capture',
    step: 'Stage 1',
    name: 'Behavioural Data',
    meta: 'Keystroke, mouse, click & scroll events collected in the session',
  },
  {
    id: 'preprocess',
    step: 'Stage 2',
    name: 'Pre-processing & Feature Extraction',
    meta: 'Raw events reduced to 6 numeric features, then min-max normalised',
  },
  {
    id: 'model',
    step: 'Stage 3',
    name: 'AI / ML Model',
    meta: 'Weighted similarity model scores each feature against the profile',
  },
  {
    id: 'compare',
    step: 'Stage 4',
    name: 'Behaviour Comparison',
    meta: 'Current session compared with the stored behaviour profile',
  },
  {
    id: 'score',
    step: 'Stage 5',
    name: 'Risk / Confidence Score',
    meta: 'Single 0-100 confidence score mapped to a risk level',
  },
];

/** Static fallback device string for the demo profile. */
export const DEMO_DEVICE = 'Windows 11 Laptop - Chrome';
