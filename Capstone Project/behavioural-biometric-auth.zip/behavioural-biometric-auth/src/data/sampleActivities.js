/**
 * Seed data for the "Recent Activities" panel (Module 3).
 * These rows exist so the dashboard never looks empty during a demo.
 */

export const SAMPLE_ACTIVITIES = [
  {
    id: 'seed-1',
    title: 'Login Successful',
    detail: 'Behaviour profile matched on first attempt',
    tone: 'good',
    icon: 'login',
    minutesAgo: 42,
  },
  {
    id: 'seed-2',
    title: 'File Access',
    detail: 'Opened /reports/semester-marks.pdf',
    tone: 'info',
    icon: 'file',
    minutesAgo: 35,
  },
  {
    id: 'seed-3',
    title: 'Data Update',
    detail: 'Updated student contact details record',
    tone: 'info',
    icon: 'edit',
    minutesAgo: 21,
  },
  {
    id: 'seed-4',
    title: 'Re-authentication Passed',
    detail: 'Mid-session behaviour check completed',
    tone: 'good',
    icon: 'shield',
    minutesAgo: 12,
  },
  {
    id: 'seed-5',
    title: 'Logout',
    detail: 'Previous session closed normally',
    tone: 'neutral',
    icon: 'logout',
    minutesAgo: 6,
  },
];

/** Activities picked at random when a successful authentication happens. */
export const FOLLOW_UP_ACTIVITIES = [
  { title: 'File Access', detail: 'Opened /documents/project-report.docx', tone: 'info', icon: 'file' },
  { title: 'Data Update', detail: 'Saved changes to the attendance sheet', tone: 'info', icon: 'edit' },
  { title: 'File Access', detail: 'Downloaded /exports/marks-summary.csv', tone: 'info', icon: 'file' },
  { title: 'Data Update', detail: 'Changed notification preferences', tone: 'info', icon: 'edit' },
];
