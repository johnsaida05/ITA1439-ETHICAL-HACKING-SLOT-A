/**
 * authService - MODULE 2 logic: the simulated AI/ML authentication engine.
 *
 * IMPORTANT (and this is the honest answer to give in the viva):
 * this is NOT a trained neural network. It is a transparent, deterministic
 * *similarity model* - the kind of baseline a real behavioural-biometric
 * system is compared against. Every number it produces can be recomputed by
 * hand on paper, which is exactly why it was chosen for a prototype.
 *
 * Pipeline implemented here:
 *
 *   features
 *     -> stage 2  min-max normalisation (pre-processing)
 *     -> stage 3  per-feature similarity   s_i = max(0, 1 - |cur - base| / (2*tol))
 *     -> stage 4  behaviour comparison     (deviation table vs the profile)
 *     -> stage 5  confidence = 100 * SUM(w_i * s_i)        [weights sum to 1]
 *                 similarity = 100 * MEAN(s_i)             [unweighted]
 *                 risk level = threshold(confidence)
 */

import { FEATURES, SIMILARITY_ZERO_MULTIPLIER } from '../data/constants';
import { clamp, round, makeId } from '../utils/formatters';
import { getRiskLevel } from '../utils/riskUtils';

/** Stage 2: min-max normalisation into 0..1 (shown in the UI as "normalised"). */
export function normaliseFeature(key, value) {
  const f = FEATURES.find((x) => x.key === key);
  if (!f) return 0;
  return round(clamp((value - f.min) / (f.max - f.min), 0, 1), 3);
}

/**
 * Stage 3: similarity of one feature.
 *
 *   deviation 0                      -> 1.00  (perfect match)
 *   deviation = 1 x tolerance        -> 0.50  (edge of the accepted band)
 *   deviation >= 2 x tolerance       -> 0.00  (no match at all)
 *
 * Linear between those points, so the score is easy to verify by hand.
 */
export function featureSimilarity(current, baseline, tolerance) {
  if (!Number.isFinite(current) || !Number.isFinite(baseline) || !tolerance) return 0;
  const deviation = Math.abs(current - baseline);
  return clamp(1 - deviation / (tolerance * SIMILARITY_ZERO_MULTIPLIER), 0, 1);
}

/**
 * Runs the whole comparison and returns a complete session record.
 *
 * @param {object}  profile   stored behaviour profile (baseline + tolerance)
 * @param {object}  features  the current session's six features
 * @param {object}  meta      { source, mode, raw, durationSec }
 */
export function evaluateSession(profile, features, meta = {}) {
  const baseline = profile?.baseline || {};
  const tolerance = profile?.tolerance || {};

  const breakdown = FEATURES.map((f) => {
    const current = Number(features?.[f.key] ?? 0);
    const base = Number(baseline[f.key] ?? f.baseline);
    const tol = Number(tolerance[f.key] ?? f.tolerance);
    const similarity = featureSimilarity(current, base, tol);

    return {
      key: f.key,
      label: f.label,
      short: f.short,
      unit: f.unit,
      group: f.group,
      decimals: f.decimals,
      weight: f.weight,
      tolerance: tol,
      baseline: round(base, f.decimals),
      current: round(current, f.decimals),
      deviation: round(current - base, f.decimals),
      absDeviation: round(Math.abs(current - base), f.decimals),
      normalisedBaseline: normaliseFeature(f.key, base),
      normalisedCurrent: normaliseFeature(f.key, current),
      similarity: round(similarity, 4),
      similarityPct: Math.round(similarity * 100),
      contribution: round(similarity * f.weight * 100, 1),
      withinTolerance: Math.abs(current - base) <= tol,
    };
  });

  const weightedSum = breakdown.reduce((sum, b) => sum + b.similarity * b.weight, 0);
  const totalWeight = breakdown.reduce((sum, b) => sum + b.weight, 0) || 1;

  const confidenceScore = Math.round(clamp((weightedSum / totalWeight) * 100, 0, 100));
  const similarityScore = Math.round(
    clamp((breakdown.reduce((s, b) => s + b.similarity, 0) / breakdown.length) * 100, 0, 100),
  );

  const risk = getRiskLevel(confidenceScore);
  const weakest = [...breakdown].sort((a, b) => a.similarity - b.similarity)[0];

  return {
    id: makeId('SES'),
    timestamp: new Date().toISOString(),
    source: meta.source || 'simulated',
    mode: meta.mode || 'genuine',
    durationSec: meta.durationSec ?? null,
    raw: meta.raw || null,
    features,
    breakdown,
    similarityScore,
    confidenceScore,
    riskLevel: risk.level,
    riskLabel: risk.riskLabel,
    status: risk.status,
    tone: risk.tone,
    message: risk.message,
    featuresOutsideTolerance: breakdown.filter((b) => !b.withinTolerance).length,
    weakestFeature: weakest ? { label: weakest.label, similarityPct: weakest.similarityPct } : null,
  };
}

/**
 * Decides whether a session should raise a security alert, and what it says.
 * Returns null when the session is healthy (score in the low-risk band).
 */
export function buildAlertForSession(session) {
  if (!session || session.riskLevel === 'low') return null;

  const critical = session.riskLevel === 'high';
  const weak = session.weakestFeature;

  return {
    id: makeId('ALR'),
    sessionId: session.id,
    timestamp: new Date().toISOString(),
    severity: critical ? 'critical' : 'warning',
    title: critical ? 'Suspicious Activity Detected' : 'Additional Verification Required',
    message: critical
      ? `Confidence score ${session.confidenceScore}/100 is below the allowed threshold of 40. Session behaviour does not match the stored profile and has been flagged.`
      : `Confidence score ${session.confidenceScore}/100 falls in the medium-risk band (40-69). A second authentication factor would be requested before access continues.`,
    confidenceScore: session.confidenceScore,
    riskLabel: session.riskLabel,
    reason: weak
      ? `Largest mismatch: ${weak.label} matched only ${weak.similarityPct}% of the profile value.`
      : 'Multiple behavioural features drifted outside the allowed tolerance.',
    featuresOutsideTolerance: session.featuresOutsideTolerance,
    action: critical ? 'Session locked - escalated to the security team' : 'Step-up verification requested',
    assignedTo: critical ? 'Security Team - Tier 2' : 'Automated verification service',
    investigationStatus: critical ? 'Under investigation' : 'Awaiting user response',
    acknowledged: false,
  };
}
