/**
 * behaviourService - MODULE 1 logic.
 *
 * Responsibilities
 *   1. Turn raw browser events (key presses, mouse moves, clicks, scrolls)
 *      into the six numeric behavioural features the model needs.
 *   2. Generate *simulated* sessions for the demo (genuine / borderline /
 *      suspicious) so the project can be presented without needing a second
 *      real person at the keyboard.
 *   3. Build and update the stored behaviour profile.
 *
 * This is a simulation. There is no hardware sensor and no real biometric
 * template - only numbers produced by the browser or by Math.random().
 */

import { FEATURES, FEATURE_MAP, DEMO_DEVICE } from '../data/constants';
import { clamp, randomBetween, randomSign, round, makeId, detectDevice } from '../utils/formatters';

/* ------------------------------------------------------------------
   1. Raw counters -> features
   ------------------------------------------------------------------ */

/** The shape of the live counter object collected while monitoring. */
export function emptyRawMetrics() {
  return {
    startedAt: null,
    durationSec: 0,
    keyPresses: 0,
    charsTyped: 0,
    holdTimeTotalMs: 0, // sum of (keyup - keydown)
    holdTimeSamples: 0,
    flightTimeTotalMs: 0, // sum of gaps between consecutive keydowns
    flightTimeSamples: 0,
    mouseMoves: 0,
    mouseDistancePx: 0,
    clicks: 0,
    scrolls: 0,
  };
}

/**
 * Pre-processing + feature extraction (pipeline stage 2).
 * Raw counters are rate-normalised against the session duration so a 10 s
 * sample and a 60 s sample are comparable.
 */
export function deriveFeatures(raw) {
  const seconds = Math.max(raw.durationSec, 1);
  const minutes = seconds / 60;

  const wpm = raw.charsTyped > 0 ? raw.charsTyped / 5 / Math.max(minutes, 1 / 60) : 0;
  const hold = raw.holdTimeSamples > 0 ? raw.holdTimeTotalMs / raw.holdTimeSamples : 0;
  const flight = raw.flightTimeSamples > 0 ? raw.flightTimeTotalMs / raw.flightTimeSamples : 0;
  const mouseSpeed = raw.mouseDistancePx > 0 ? raw.mouseDistancePx / seconds : 0;

  return {
    typingSpeed: round(clamp(wpm, 0, FEATURE_MAP.typingSpeed.max), 1),
    keyHoldTime: round(clamp(hold, 0, FEATURE_MAP.keyHoldTime.max), 0),
    flightTime: round(clamp(flight, 0, FEATURE_MAP.flightTime.max), 0),
    mouseSpeed: round(clamp(mouseSpeed, 0, FEATURE_MAP.mouseSpeed.max), 0),
    clickRate: round(clamp(raw.clicks / minutes, 0, FEATURE_MAP.clickRate.max), 1),
    scrollRate: round(clamp(raw.scrolls / minutes, 0, FEATURE_MAP.scrollRate.max), 1),
  };
}

/**
 * Is there enough captured data to authenticate on?
 * Below this bar the app falls back to a simulated session and says so.
 */
export function hasEnoughData(raw) {
  return raw.durationSec >= 5 && raw.keyPresses >= 12 && raw.mouseMoves >= 25;
}

/* ------------------------------------------------------------------
   2. Simulated activity (keeps the demo moving with no user input)
   ------------------------------------------------------------------ */

/**
 * One second of synthetic activity, added to the raw counters when the
 * "auto-simulate activity" switch is on. Values are centred on the profile
 * baseline when a profile exists, so simulated sessions look genuine.
 */
export function simulateOneSecond(raw, profile, mode = 'genuine') {
  const base = profile?.baseline || defaultBaseline();
  const drift = mode === 'suspicious' ? randomBetween(1.9, 3.0) : randomBetween(-0.45, 0.45);
  const sign = mode === 'suspicious' ? randomSign() : 1;

  const target = (key) => {
    const f = FEATURE_MAP[key];
    const value = base[key] + sign * drift * f.tolerance * (mode === 'suspicious' ? 1 : 1);
    return clamp(value, f.min, f.max);
  };

  const wpm = target('typingSpeed');
  const hold = target('keyHoldTime');
  const flight = target('flightTime');
  const mouseSpeed = target('mouseSpeed');
  const clickRate = target('clickRate');
  const scrollRate = target('scrollRate');

  // chars/second implied by the target WPM (1 word == 5 chars)
  const charsThisSecond = Math.max(0, Math.round((wpm * 5) / 60 + randomBetween(-0.6, 0.6)));

  return {
    ...raw,
    keyPresses: raw.keyPresses + charsThisSecond,
    charsTyped: raw.charsTyped + charsThisSecond,
    holdTimeTotalMs: raw.holdTimeTotalMs + hold * charsThisSecond,
    holdTimeSamples: raw.holdTimeSamples + charsThisSecond,
    flightTimeTotalMs: raw.flightTimeTotalMs + flight * charsThisSecond,
    flightTimeSamples: raw.flightTimeSamples + charsThisSecond,
    mouseMoves: raw.mouseMoves + Math.round(randomBetween(8, 26)),
    mouseDistancePx: raw.mouseDistancePx + mouseSpeed,
    clicks: raw.clicks + (Math.random() < clickRate / 60 ? 1 : 0),
    scrolls: raw.scrolls + (Math.random() < scrollRate / 60 ? 1 : 0),
  };
}

/* ------------------------------------------------------------------
   3. Profile handling
   ------------------------------------------------------------------ */

function defaultBaseline() {
  return FEATURES.reduce((acc, f) => {
    acc[f.key] = f.baseline;
    return acc;
  }, {});
}

function defaultTolerance() {
  return FEATURES.reduce((acc, f) => {
    acc[f.key] = f.tolerance;
    return acc;
  }, {});
}

/**
 * Enrollment: builds the stored behaviour profile.
 * With no `features` argument it generates a plausible baseline by jittering
 * the demo defaults, which is what the "Create / Update Behaviour Profile"
 * button does during a presentation.
 */
export function buildProfile({ username = 'student', features = null, existing = null } = {}) {
  const baseline = FEATURES.reduce((acc, f) => {
    if (features && Number.isFinite(features[f.key]) && features[f.key] > 0) {
      acc[f.key] = round(features[f.key], f.decimals);
    } else {
      // +/- 18% jitter around the demo default so each profile looks individual
      acc[f.key] = round(clamp(f.baseline * randomBetween(0.82, 1.18), f.min, f.max), f.decimals);
    }
    return acc;
  }, {});

  const now = new Date().toISOString();

  return {
    userId: existing?.userId || makeId('USR'),
    username,
    device: existing?.device || detectDevice() || DEMO_DEVICE,
    createdAt: existing?.createdAt || now,
    updatedAt: now,
    source: features ? 'live capture' : 'simulated enrollment',
    samplesUsed: existing?.samplesUsed ? existing.samplesUsed + 1 : 1,
    baseline,
    tolerance: defaultTolerance(),
  };
}

/** Normalises an older/partial stored profile so the UI never sees holes. */
export function hydrateProfile(stored) {
  if (!stored || typeof stored !== 'object') return null;
  const baseline = { ...defaultBaseline(), ...(stored.baseline || {}) };
  const tolerance = { ...defaultTolerance(), ...(stored.tolerance || {}) };
  return { ...stored, baseline, tolerance };
}

/* ------------------------------------------------------------------
   4. Session generation (used by Run Authentication Test / Simulate Suspicious)
   ------------------------------------------------------------------ */

/**
 * Produces a full set of features for a brand-new session.
 *
 * The ranges are expressed in multiples of the feature tolerance, and are
 * chosen so each mode reliably lands in its own risk band (similarity reaches
 * zero at 2 x tolerance - see authService.featureSimilarity):
 *
 *   genuine     0.05 - 0.55 tolerance away  -> confidence ~72-97  (low risk)
 *   borderline  0.70 - 1.20 tolerance away  -> confidence ~40-65  (medium risk)
 *   suspicious  1.25 - 2.20 tolerance away  -> confidence ~5-30   (high risk)
 */
export function generateSessionFeatures(profile, mode = 'genuine') {
  const base = profile?.baseline || defaultBaseline();
  const tol = profile?.tolerance || defaultTolerance();

  const spread = {
    genuine: [0.05, 0.55],
    borderline: [0.7, 1.2],
    suspicious: [1.25, 2.2],
  }[mode] || [0.05, 0.55];

  return FEATURES.reduce((acc, f) => {
    const offset = randomBetween(spread[0], spread[1]) * (tol[f.key] ?? f.tolerance) * randomSign();
    acc[f.key] = round(clamp(base[f.key] + offset, f.min, f.max), f.decimals);
    return acc;
  }, {});
}

/**
 * Turns features into the raw-looking counters shown on the capture page, so a
 * simulated session can still populate "mouse movement count", "click count"
 * etc. without pretending to have recorded real events.
 */
export function rawFromFeatures(features, durationSec = 30) {
  const minutes = durationSec / 60;
  const chars = Math.round((features.typingSpeed * 5) * minutes);
  return {
    startedAt: new Date(Date.now() - durationSec * 1000).toISOString(),
    durationSec,
    keyPresses: chars,
    charsTyped: chars,
    holdTimeTotalMs: features.keyHoldTime * Math.max(chars, 1),
    holdTimeSamples: Math.max(chars, 1),
    flightTimeTotalMs: features.flightTime * Math.max(chars, 1),
    flightTimeSamples: Math.max(chars, 1),
    mouseMoves: Math.round(durationSec * randomBetween(9, 18)),
    mouseDistancePx: Math.round(features.mouseSpeed * durationSec),
    clicks: Math.round(features.clickRate * minutes),
    scrolls: Math.round(features.scrollRate * minutes),
  };
}
