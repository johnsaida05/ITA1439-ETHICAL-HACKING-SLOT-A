/**
 * storageService - the only module that talks to localStorage.
 *
 * Everything the demo "remembers" between page reloads lives here:
 *   - the enrolled behaviour profile (Module 1 output / Module 2 input)
 *   - the authentication session history (Module 2 output)
 *   - the security alert log (Module 3)
 *   - the recent activity feed (Module 3)
 *   - the demo login flag
 *
 * All reads are defensive: if a key is missing or corrupted we fall back to a
 * default instead of crashing the UI, which matters during a live demo.
 */

const PREFIX = 'bioauth.';

export const KEYS = {
  PROFILE: `${PREFIX}profile`,
  SESSIONS: `${PREFIX}sessions`,
  ALERTS: `${PREFIX}alerts`,
  ACTIVITIES: `${PREFIX}activities`,
  AUTH: `${PREFIX}loggedIn`,
};

function available() {
  try {
    return typeof window !== 'undefined' && !!window.localStorage;
  } catch {
    return false;
  }
}

export function readJson(key, fallback) {
  if (!available()) return fallback;
  try {
    const raw = window.localStorage.getItem(key);
    if (!raw) return fallback;
    const parsed = JSON.parse(raw);
    return parsed === null || parsed === undefined ? fallback : parsed;
  } catch (err) {
    console.warn(`[storageService] could not read ${key}:`, err.message);
    return fallback;
  }
}

export function writeJson(key, value) {
  if (!available()) return;
  try {
    window.localStorage.setItem(key, JSON.stringify(value));
  } catch (err) {
    console.warn(`[storageService] could not write ${key}:`, err.message);
  }
}

export function removeKey(key) {
  if (!available()) return;
  try {
    window.localStorage.removeItem(key);
  } catch {
    /* ignore */
  }
}

/* ---------- Behaviour profile ---------- */

export const loadProfile = () => readJson(KEYS.PROFILE, null);
export const saveProfile = (profile) => writeJson(KEYS.PROFILE, profile);

/* ---------- Session history ---------- */

export const loadSessions = () => {
  const list = readJson(KEYS.SESSIONS, []);
  return Array.isArray(list) ? list : [];
};
export const saveSessions = (sessions) => writeJson(KEYS.SESSIONS, sessions.slice(0, 40));

/* ---------- Security alerts ---------- */

export const loadAlerts = () => {
  const list = readJson(KEYS.ALERTS, []);
  return Array.isArray(list) ? list : [];
};
export const saveAlerts = (alerts) => writeJson(KEYS.ALERTS, alerts.slice(0, 40));

/* ---------- Activity feed ---------- */

export const loadActivities = () => {
  const list = readJson(KEYS.ACTIVITIES, null);
  return Array.isArray(list) ? list : null;
};
export const saveActivities = (activities) => writeJson(KEYS.ACTIVITIES, activities.slice(0, 40));

/* ---------- Demo login flag ---------- */

export const loadLoggedIn = () => readJson(KEYS.AUTH, false) === true;
export const saveLoggedIn = (value) => writeJson(KEYS.AUTH, value === true);

/* ---------- Reset ---------- */

/** Wipes every demo key. Used by the "Reset Demo" button. */
export function clearDemoData({ keepLogin = true } = {}) {
  removeKey(KEYS.PROFILE);
  removeKey(KEYS.SESSIONS);
  removeKey(KEYS.ALERTS);
  removeKey(KEYS.ACTIVITIES);
  if (!keepLogin) removeKey(KEYS.AUTH);
}
