import { Navigate, Route, Routes } from 'react-router-dom';

import Navbar from './components/Navbar';
import Sidebar from './components/Sidebar';
import AboutProject from './pages/AboutProject';
import AiAuthentication from './pages/AiAuthentication';
import BehaviourCapture from './pages/BehaviourCapture';
import Dashboard from './pages/Dashboard';
import Login from './pages/Login';
import SecurityAlerts from './pages/SecurityAlerts';
import UserProfile from './pages/UserProfile';
import { useApp } from './context/AppContext';

/** The dashboard shell: sidebar + navbar + routed page. */
function Shell() {
  return (
    <div className="app-shell">
      <Sidebar />
      <div className="app-main">
        <Navbar />
        <main className="page-body">
          <Routes>
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/capture" element={<BehaviourCapture />} />
            <Route path="/authentication" element={<AiAuthentication />} />
            <Route path="/alerts" element={<SecurityAlerts />} />
            <Route path="/profile" element={<UserProfile />} />
            <Route path="/about" element={<AboutProject />} />
            <Route path="*" element={<Navigate to="/dashboard" replace />} />
          </Routes>
        </main>
      </div>
    </div>
  );
}

export default function App() {
  const { loggedIn } = useApp();
  return loggedIn ? <Shell /> : <Login />;
}
