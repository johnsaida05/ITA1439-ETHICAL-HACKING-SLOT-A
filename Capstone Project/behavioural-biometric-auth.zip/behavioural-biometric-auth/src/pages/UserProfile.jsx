import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';

import BehaviorDataTable from '../components/BehaviorDataTable';
import Card from '../components/Card';
import DemoBanner from '../components/DemoBanner';
import StatusBadge from '../components/StatusBadge';
import { IconActivity, IconArrowRight, IconRefresh, IconUser } from '../components/Icons';
import { FEATURES, DEMO_CREDENTIALS } from '../data/constants';
import { useApp } from '../context/AppContext';
import { formatDate, formatDateTime, round } from '../utils/formatters';

/**
 * User Profile / enrollment page.
 * "Create / Update Behaviour Profile" writes the baseline into localStorage -
 * this is the stored template that Module 2 compares every session against.
 */
export default function UserProfile() {
  const { profile, createOrUpdateProfile, captureReady, liveFeatures, sessions } = useApp();
  const [username, setUsername] = useState(profile?.username || DEMO_CREDENTIALS.username);
  const [notice, setNotice] = useState('');

  const baselineRows = useMemo(
    () =>
      FEATURES.map((f) => ({
        key: f.key,
        label: f.label,
        group: f.group,
        unit: f.unit,
        decimals: f.decimals,
        weight: f.weight,
        baseline: round(profile?.baseline?.[f.key] ?? f.baseline, f.decimals),
        tolerance: profile?.tolerance?.[f.key] ?? f.tolerance,
      })),
    [profile],
  );

  const handleCreate = (fromLive) => {
    createOrUpdateProfile({ fromLive, username: username.trim() || DEMO_CREDENTIALS.username });
    setNotice(
      fromLive
        ? 'Behaviour profile enrolled from the live captured session and saved to localStorage.'
        : 'Behaviour profile created from generated sample behaviour and saved to localStorage.',
    );
    window.setTimeout(() => setNotice(''), 5000);
  };

  return (
    <div className="stack">
      <DemoBanner>
        <strong>Demo enrollment.</strong> A real system would average many genuine sessions to build
        the template. Here the baseline is either generated sample data or a single captured session,
        and it is stored unencrypted in <code>localStorage</code> because this is a classroom
        prototype, not a production system.
      </DemoBanner>

      {notice && (
        <div className="demo-banner" style={{ background: 'var(--good-wash)', borderColor: '#bfe6bf', color: 'var(--good-text)' }}>
          <p>{notice}</p>
        </div>
      )}

      <div className="grid grid--main">
        <Card
          title="User Details"
          hint="Identity attached to the stored behaviour profile"
          actions={
            <StatusBadge tone={profile ? 'good' : 'warning'}>
              {profile ? 'Profile Active' : 'Not Enrolled'}
            </StatusBadge>
          }
        >
          <div className="kv">
            <div className="kv__cell">
              <div className="kv__k">User ID</div>
              <div className="kv__v mono" style={{ fontSize: 12.5 }}>{profile?.userId || 'Not generated'}</div>
            </div>
            <div className="kv__cell">
              <div className="kv__k">Username</div>
              <div className="kv__v">{profile?.username || '--'}</div>
            </div>
            <div className="kv__cell">
              <div className="kv__k">Registered Device</div>
              <div className="kv__v" style={{ fontSize: 12.5 }}>{profile?.device || '--'}</div>
            </div>
            <div className="kv__cell">
              <div className="kv__k">Behaviour Profile Status</div>
              <div className="kv__v">{profile ? 'Enrolled and active' : 'Not created'}</div>
            </div>
            <div className="kv__cell">
              <div className="kv__k">Registration Date</div>
              <div className="kv__v">{profile ? formatDate(profile.createdAt) : '--'}</div>
            </div>
            <div className="kv__cell">
              <div className="kv__k">Last Updated</div>
              <div className="kv__v" style={{ fontSize: 12.5 }}>
                {profile ? formatDateTime(profile.updatedAt) : '--'}
              </div>
            </div>
            <div className="kv__cell">
              <div className="kv__k">Enrollment Source</div>
              <div className="kv__v" style={{ fontSize: 12.5 }}>{profile?.source || '--'}</div>
            </div>
            <div className="kv__cell">
              <div className="kv__k">Sessions Evaluated</div>
              <div className="kv__v mono">{sessions.length}</div>
            </div>
          </div>
        </Card>

        <Card title="Enrollment" hint="Create or replace the stored baseline">
          <div className="field">
            <label htmlFor="profile-username">Username for the profile</label>
            <input
              id="profile-username"
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="student"
            />
          </div>

          <div className="stack mt-14" style={{ gap: 9 }}>
            <button type="button" className="btn btn--accent btn--block" onClick={() => handleCreate(false)}>
              <IconUser size={14} /> Create / Update Behaviour Profile
            </button>

            <button
              type="button"
              className="btn btn--block"
              onClick={() => handleCreate(true)}
              disabled={!captureReady}
              title={captureReady ? 'Use the live captured session as the baseline' : 'Capture more data on the Behaviour Capture page first'}
            >
              <IconActivity size={14} /> Enroll from live captured session
            </button>

            {!captureReady && (
              <p className="small muted">
                Live enrollment unlocks once Module 1 has captured 5 s, 12 key events and 25 mouse
                events. <Link to="/capture">Open Behaviour Capture</Link>.
              </p>
            )}

            {profile && (
              <p className="small muted">
                Re-running enrollment overwrites the baseline and keeps the same User ID
                (update #{profile.samplesUsed}).
              </p>
            )}
          </div>
        </Card>
      </div>

      <Card
        title="Stored Behaviour Profile (baseline template)"
        hint="These six values are what every future session is compared against"
        actions={
          profile && (
            <Link className="btn btn--sm btn--accent" to="/authentication">
              Run authentication <IconArrowRight size={13} />
            </Link>
          )
        }
        flush
      >
        {profile ? (
          <BehaviorDataTable rows={baselineRows} variant="baseline" />
        ) : (
          <p className="empty">
            No profile stored yet. Press <strong>Create / Update Behaviour Profile</strong> above.
          </p>
        )}
      </Card>

      {captureReady && (
        <Card title="Live captured session (candidate baseline)" hint="What would be stored if you enroll from live capture">
          <div className="grid grid--3">
            {FEATURES.map((f) => (
              <div className="kv__cell" key={f.key} style={{ border: '1px solid var(--border)', borderRadius: 6 }}>
                <div className="kv__k">{f.label}</div>
                <div className="kv__v mono">
                  {liveFeatures[f.key]} <span className="small muted">{f.unit}</span>
                </div>
              </div>
            ))}
          </div>
        </Card>
      )}

      <Card title="Demo data stored in this browser" hint="Everything the prototype persists">
        <div className="prose">
          <ul>
            <li><code>bioauth.profile</code> - the enrolled behaviour baseline and tolerances</li>
            <li><code>bioauth.sessions</code> - the last 40 evaluated sessions with their scores</li>
            <li><code>bioauth.alerts</code> - the security alert log</li>
            <li><code>bioauth.activities</code> - the recent-activity feed</li>
            <li><code>bioauth.loggedIn</code> - the demo login flag</li>
          </ul>
          <p className="mt-10">
            Use <strong>Reset demo</strong> in the top bar (press it twice to confirm) to clear all of
            this and start the presentation from a clean state.
          </p>
        </div>
        <div className="row mt-14">
          <StatusBadge tone="info">
            <IconRefresh size={12} /> Reset is available in the top navigation bar
          </StatusBadge>
        </div>
      </Card>
    </div>
  );
}
