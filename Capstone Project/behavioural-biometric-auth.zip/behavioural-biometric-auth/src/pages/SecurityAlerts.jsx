import Card from '../components/Card';
import DemoBanner from '../components/DemoBanner';
import MetricCard from '../components/MetricCard';
import SecurityAlert, { NoAlerts } from '../components/SecurityAlert';
import StatusBadge from '../components/StatusBadge';
import { IconAlert, IconRefresh } from '../components/Icons';
import { useApp } from '../context/AppContext';
import { formatDateTime, timeAgo } from '../utils/formatters';

/** The escalation steps shown in the investigation panel. */
const RUNBOOK = [
  { step: 1, action: 'Session flagged automatically', owner: 'Module 3 - alert engine', detail: 'Triggered the moment the confidence score falls below 70.' },
  { step: 2, action: 'Step-up verification requested', owner: 'Authentication service', detail: 'Medium-risk sessions (40-69) are asked for a second factor.' },
  { step: 3, action: 'Session locked', owner: 'Authentication service', detail: 'High-risk sessions (0-39) are blocked immediately.' },
  { step: 4, action: 'Manual review', owner: 'Admin / Security Team - Tier 2', detail: 'An analyst checks the behaviour comparison table for the flagged session.' },
  { step: 5, action: 'Outcome recorded', owner: 'Admin / Security Team', detail: 'Alert is marked reviewed, and the profile is re-enrolled if the drift was genuine.' },
];

/**
 * MODULE 3 (second half) - Security Alerts and the investigation view.
 */
export default function SecurityAlerts() {
  const { alerts, openAlerts, acknowledgeAlert, clearAlerts, simulateSuspicious, profile } = useApp();

  const criticalCount = alerts.filter((a) => a.severity === 'critical').length;
  const latest = alerts[0] || null;

  return (
    <div className="stack">
      <DemoBanner tone="warning">
        <strong>Simulated alerts only.</strong> Nothing here detects a real attack. An alert is
        raised purely because the simulated confidence score for a session fell below the demo
        threshold of 70 - there is no network monitoring, no intrusion detection and no real user
        being watched.
      </DemoBanner>

      <div className="grid grid--4">
        <MetricCard label="Total Alerts" value={alerts.length} icon="alert" footnote="Stored in localStorage" />
        <MetricCard
          label="Open Alerts"
          value={openAlerts.length}
          icon="shield"
          footnote={openAlerts.length === 0 ? 'No Alerts' : 'Awaiting review'}
        />
        <MetricCard
          label="High-Risk Alerts"
          value={criticalCount}
          icon="alert"
          footnote="Confidence below 40"
        />
        <MetricCard
          label="Last Alert"
          value={latest ? timeAgo(latest.timestamp) : '--'}
          icon="clock"
          footnote={latest ? formatDateTime(latest.timestamp) : 'No alerts generated yet'}
        />
      </div>

      <Card
        title="Alert controls"
        hint="Use these during the presentation to show both the healthy and the flagged state"
      >
        <div className="row">
          <button type="button" className="btn btn--danger" onClick={simulateSuspicious} disabled={!profile}>
            <IconAlert size={14} /> Simulate Suspicious Activity
          </button>
          <button type="button" className="btn" onClick={clearAlerts} disabled={alerts.length === 0}>
            <IconRefresh size={14} /> Clear alert log
          </button>
          <StatusBadge tone={openAlerts.length === 0 ? 'good' : 'critical'}>
            {openAlerts.length === 0 ? 'No Alerts' : `${openAlerts.length} open alert(s)`}
          </StatusBadge>
          {!profile && <span className="small muted">Enroll a behaviour profile to enable the simulation.</span>}
        </div>
      </Card>

      <Card
        title="Security Alert Log"
        hint="Newest first - generated automatically from low-confidence sessions"
        flush={alerts.length === 0}
      >
        {alerts.length === 0 ? (
          <NoAlerts />
        ) : (
          <div className="stack" style={{ gap: 12 }}>
            {alerts.map((alert) => (
              <SecurityAlert key={alert.id} alert={alert} onAcknowledge={acknowledgeAlert} />
            ))}
          </div>
        )}
      </Card>

      <div className="grid grid--2">
        <Card title="Admin / Security Team - Investigation" hint="Queue view of every flagged session" flush>
          {alerts.length === 0 ? (
            <p className="empty">Investigation queue is empty.</p>
          ) : (
            <div className="table-wrap">
              <table className="data">
                <thead>
                  <tr>
                    <th>Alert</th>
                    <th>Score</th>
                    <th>Assigned to</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {alerts.map((a) => (
                    <tr key={a.id}>
                      <td>
                        <div className="feature-name">{a.title}</div>
                        <div className="sub mono">{a.id}</div>
                      </td>
                      <td className="num" style={{ fontWeight: 650 }}>{a.confidenceScore}</td>
                      <td>{a.assignedTo}</td>
                      <td>
                        <StatusBadge tone={a.acknowledged ? 'good' : a.severity === 'critical' ? 'critical' : 'warning'}>
                          {a.acknowledged ? 'Reviewed' : a.investigationStatus}
                        </StatusBadge>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Card>

        <Card title="Escalation flow" hint="What the prototype models after an alert is raised" flush>
          <div className="table-wrap">
            <table className="data">
              <thead>
                <tr>
                  <th>Step</th>
                  <th>Action</th>
                  <th>Owner</th>
                </tr>
              </thead>
              <tbody>
                {RUNBOOK.map((r) => (
                  <tr key={r.step}>
                    <td className="num">{r.step}</td>
                    <td>
                      <div className="feature-name">{r.action}</div>
                      <div className="sub">{r.detail}</div>
                    </td>
                    <td className="nowrap">{r.owner}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      </div>
    </div>
  );
}
