import { useState } from 'react';

import { APP_TITLE, DEMO_CREDENTIALS } from '../data/constants';
import { useApp } from '../context/AppContext';
import { IconLogin, IconShieldCheck } from '../components/Icons';

const FLOW = [
  'User',
  'Behavioural Data Capture',
  'Pre-processing',
  'AI/ML Authentication',
  'Behaviour Comparison',
  'Risk / Confidence Score',
  'Dashboard / Security Alert',
];

/**
 * Demo login screen.
 * The credential check is a plain string comparison in the browser - it exists
 * to frame the story ("password first, behaviour second"), not to provide
 * security. Real credentials would never be handled this way.
 */
export default function Login() {
  const { login } = useApp();
  const [username, setUsername] = useState(DEMO_CREDENTIALS.username);
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    const ok = login(username, password);
    if (!ok) setError('Incorrect demo credentials. Use the sample credentials shown below.');
    else setError('');
  };

  return (
    <div className="login">
      <section className="login__hero">
        <span className="login__eyebrow">College Capstone Project</span>
        <h1 className="login__title">{APP_TITLE}</h1>
        <p className="login__lead">
          A working front-end prototype that identifies a user by <em>how</em> they type, move the
          mouse, click and scroll - then turns that behaviour into a confidence score, a risk level
          and, when the score drops, a security alert.
        </p>
        <div className="login__flow">
          {FLOW.map((step) => (
            <span className="login__chip" key={step}>
              {step}
            </span>
          ))}
        </div>
        <p className="login__lead" style={{ fontSize: 12.5 }}>
          Simulated AI/ML demo. No biometric hardware, no trained model, no backend - everything runs
          in this browser tab and is stored in localStorage.
        </p>
      </section>

      <form className="login__panel" onSubmit={handleSubmit}>
        <div>
          <span className="sidebar__logo" style={{ background: 'var(--series-1)' }}>
            <IconShieldCheck size={20} />
          </span>
          <h2 style={{ fontSize: 22, marginTop: 14 }}>Sign in to the demo</h2>
          <p className="text-sm mt-6">
            Step 1 is the ordinary password check. Step 2 - the behavioural layer - starts the moment
            you are inside.
          </p>
        </div>

        <div className="field">
          <label htmlFor="username">Username</label>
          <input
            id="username"
            type="text"
            autoComplete="username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            placeholder="student"
          />
        </div>

        <div className="field">
          <label htmlFor="password">Password</label>
          <input
            id="password"
            type="password"
            autoComplete="current-password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="demo123"
          />
        </div>

        {error && <p className="form-error">{error}</p>}

        <button type="submit" className="btn btn--accent btn--block">
          <IconLogin size={15} /> Sign in
        </button>

        <div className="creds">
          <strong>Sample credentials</strong>
          <br />
          Username: <code>{DEMO_CREDENTIALS.username}</code>
          <br />
          Password: <code>{DEMO_CREDENTIALS.password}</code>
        </div>
      </form>
    </div>
  );
}
