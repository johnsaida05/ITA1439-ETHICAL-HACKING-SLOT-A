import Card from '../components/Card';
import DemoBanner from '../components/DemoBanner';
import PipelineFlow from '../components/PipelineFlow';
import StatusBadge from '../components/StatusBadge';
import { APP_TITLE, APP_VERSION, FEATURES, DEMO_CREDENTIALS } from '../data/constants';
import { THRESHOLD_ROWS } from '../utils/riskUtils';

const MODULES = [
  {
    id: 'Module 1',
    name: 'Behavioural Data Capture',
    file: 'src/pages/BehaviourCapture.jsx + src/services/behaviourService.js',
    what: 'Collects keystroke timings, mouse path length, click and scroll counts from real browser events, and optionally adds simulated events once per second so the metrics keep moving during a demo. Raw counters are then reduced to six numeric features.',
  },
  {
    id: 'Module 2',
    name: 'AI-Based User Authentication',
    file: 'src/pages/AiAuthentication.jsx + src/services/authService.js',
    what: 'Walks through the five pipeline stages, compares the current session against the stored profile feature by feature, and produces a similarity score, a confidence score and a risk level.',
  },
  {
    id: 'Module 3',
    name: 'Authentication Dashboard & Security Alerts',
    file: 'src/pages/Dashboard.jsx + src/pages/SecurityAlerts.jsx',
    what: 'Shows the authentication status, the confidence gauge, the live activity chart, the recent activity feed, and raises a security alert automatically whenever a session scores below 70.',
  },
];

const STACK = [
  { name: 'React 18', role: 'Component-based UI and routing (react-router-dom)' },
  { name: 'Vite', role: 'Dev server and production build' },
  { name: 'Recharts', role: 'Area, line and bar charts' },
  { name: 'Plain CSS', role: 'Design tokens in src/styles/global.css - no UI framework' },
  { name: 'localStorage', role: 'Stores the behaviour profile, sessions, alerts and activity feed' },
  { name: 'Inline SVG', role: 'Icons and the hand-built confidence gauge - zero icon dependencies' },
];

const NOT_INCLUDED = [
  'No biometric hardware, camera, fingerprint reader or any physical sensor',
  'No trained machine-learning model, no training data and no inference server',
  'No backend, database, API or user accounts - the whole app runs in the browser tab',
  'No real intrusion detection, network monitoring or attack analysis',
  'No surveillance of anyone: only this browser tab, only while monitoring is on, and nothing is transmitted',
];

/** About page - the reference sheet to open during the viva. */
export default function AboutProject() {
  return (
    <div className="stack">
      <Card title={APP_TITLE} hint={`Capstone project prototype - version ${APP_VERSION}`}>
        <div className="prose">
          <p>
            This website is a working front-end prototype of a behavioural biometric authentication
            system. Instead of asking &quot;what does the user know&quot; (a password) or &quot;what
            does the user have&quot; (an OTP device), behavioural biometrics ask{' '}
            <strong>&quot;does this session behave like the enrolled user?&quot;</strong> - using
            typing rhythm, mouse motion and click/scroll habits.
          </p>
          <p className="mt-10">
            The prototype implements the complete data flow end to end, with a transparent scoring
            function standing in for the machine-learning model.
          </p>
        </div>

        <div className="mt-14">
          <PipelineFlow completed />
        </div>

        <div className="row mt-14">
          <StatusBadge tone="info">User</StatusBadge>
          <span className="muted">-&gt;</span>
          <StatusBadge tone="info">Behavioural Data Capture</StatusBadge>
          <span className="muted">-&gt;</span>
          <StatusBadge tone="info">Pre-processing</StatusBadge>
          <span className="muted">-&gt;</span>
          <StatusBadge tone="info">AI/ML Authentication</StatusBadge>
          <span className="muted">-&gt;</span>
          <StatusBadge tone="info">Behaviour Comparison</StatusBadge>
          <span className="muted">-&gt;</span>
          <StatusBadge tone="info">Risk / Confidence Score</StatusBadge>
          <span className="muted">-&gt;</span>
          <StatusBadge tone="good">Dashboard</StatusBadge>
          <span className="muted">/</span>
          <StatusBadge tone="critical">Security Alert</StatusBadge>
        </div>
      </Card>

      <DemoBanner tone="warning">
        <strong>Scope statement for the review panel.</strong> This is a simulation built for
        academic demonstration. The confidence score comes from an explainable weighted-similarity
        formula, not from a trained AI model, and no real biometric data is captured, transmitted or
        stored anywhere outside this browser.
      </DemoBanner>

      <div className="grid grid--3">
        {MODULES.map((m) => (
          <Card key={m.id} title={`${m.id} - ${m.name}`} hint={m.file}>
            <p className="text-sm">{m.what}</p>
          </Card>
        ))}
      </div>

      <div className="grid grid--2">
        <Card title="The simulated AI/ML algorithm" hint="Explainable by design">
          <div className="formula">
{`INPUT   profile.baseline[i], profile.tolerance[i], session.current[i]

1  normalise   n_i = (x_i - min_i) / (max_i - min_i)        (display only)
2  deviation   d_i = | current_i - baseline_i |
3  similarity  s_i = max(0, 1 - d_i / (2 x tolerance_i))
               d_i = 0         -> s_i = 1.00
               d_i = tolerance -> s_i = 0.50
               d_i >= 2 x tol  -> s_i = 0.00
4  confidence  C   = 100 x SUM(w_i x s_i)       with SUM(w_i) = 1
5  similarity  S   = 100 x mean(s_i)
6  decision    C >= 70 -> Authenticated
               C >= 40 -> Verification Required
               else    -> Suspicious Activity`}
          </div>

          <div className="prose mt-14">
            <h4>Why this instead of a neural network?</h4>
            <ul>
              <li>Every score can be recomputed by hand, so the demo can be explained line by line.</li>
              <li>It needs no training data, which a classroom project cannot collect ethically.</li>
              <li>
                It is the standard <em>distance-to-template</em> baseline that real behavioural
                biometric papers compare their models against - so the concept being demonstrated is
                genuine even though the implementation is simple.
              </li>
            </ul>
            <h4 className="mt-10">What a production system would add</h4>
            <ul>
              <li>Many enrollment sessions averaged into the template, with per-user standard deviations instead of fixed tolerances.</li>
              <li>A trained classifier (one-class SVM, random forest or an LSTM over keystroke sequences) in place of step 3.</li>
              <li>Server-side scoring, encrypted templates and continuous re-authentication.</li>
            </ul>
          </div>
        </Card>

        <div className="stack">
          <Card title="Feature set and model weights" flush>
            <div className="table-wrap">
              <table className="data">
                <thead>
                  <tr>
                    <th>Feature</th>
                    <th>Group</th>
                    <th>Unit</th>
                    <th>Weight</th>
                  </tr>
                </thead>
                <tbody>
                  {FEATURES.map((f) => (
                    <tr key={f.key}>
                      <td className="feature-name">{f.label}</td>
                      <td className="sub">{f.group}</td>
                      <td className="sub">{f.unit}</td>
                      <td className="num" style={{ fontWeight: 650 }}>{f.weight.toFixed(2)}</td>
                    </tr>
                  ))}
                  <tr>
                    <td colSpan={3} style={{ fontWeight: 650 }}>Total</td>
                    <td className="num" style={{ fontWeight: 650 }}>1.00</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </Card>

          <Card title="Decision thresholds" flush>
            <div className="table-wrap">
              <table className="data">
                <thead>
                  <tr>
                    <th>Score</th>
                    <th>Risk</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {THRESHOLD_ROWS.map((r) => (
                    <tr key={r.range}>
                      <td className="num feature-name">{r.range}</td>
                      <td>
                        <StatusBadge tone={r.tone}>{r.risk}</StatusBadge>
                      </td>
                      <td>{r.status}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        </div>
      </div>

      <div className="grid grid--2">
        <Card title="Technology stack" flush>
          <div className="table-wrap">
            <table className="data">
              <thead>
                <tr>
                  <th>Technology</th>
                  <th>Role in the project</th>
                </tr>
              </thead>
              <tbody>
                {STACK.map((s) => (
                  <tr key={s.name}>
                    <td className="feature-name nowrap">{s.name}</td>
                    <td>{s.role}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>

        <Card title="Deliberately out of scope" hint="Say this clearly if the panel asks about security claims">
          <div className="prose">
            <ul>
              {NOT_INCLUDED.map((n) => (
                <li key={n}>{n}</li>
              ))}
            </ul>
          </div>
        </Card>
      </div>

      <Card title="Suggested demo script" hint="Five minutes, in order">
        <div className="prose">
          <ol>
            <li>Log in with <code>{DEMO_CREDENTIALS.username}</code> / <code>{DEMO_CREDENTIALS.password}</code> and show the dashboard overview.</li>
            <li>Open <strong>User Profile</strong> and press <strong>Create / Update Behaviour Profile</strong> - explain that this is enrollment.</li>
            <li>Go to <strong>Behaviour Capture</strong>, press <strong>Start Monitoring</strong>, type in the capture box and move the mouse. Point out the live metrics and the activity chart.</li>
            <li>Go to <strong>AI Authentication</strong> and press <strong>Run Authentication Test</strong>. Walk through the five pipeline stages and the comparison table.</li>
            <li>Press <strong>Simulate Suspicious Activity</strong> - the score collapses, the risk turns red and a security alert appears.</li>
            <li>Open <strong>Security Alerts</strong> and show the alert plus the Admin / Security Team investigation queue.</li>
            <li>Finish on the <strong>Dashboard</strong>, then press <strong>Reset demo</strong> twice to return to a clean state.</li>
          </ol>
        </div>
      </Card>
    </div>
  );
}
