import { useCallback, useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';

import BehaviorDataTable from '../components/BehaviorDataTable';
import Card from '../components/Card';
import ConfidenceScore from '../components/ConfidenceScore';
import DemoBanner from '../components/DemoBanner';
import MetricCard from '../components/MetricCard';
import PipelineFlow from '../components/PipelineFlow';
import RiskIndicator from '../components/RiskIndicator';
import SimilarityChart from '../components/SimilarityChart';
import StatusBadge from '../components/StatusBadge';
import { IconAlert, IconArrowRight, IconPlay, IconShield, IconUser } from '../components/Icons';
import { useApp } from '../context/AppContext';
import { THRESHOLD_ROWS } from '../utils/riskUtils';
import { formatDateTime, timeAgo } from '../utils/formatters';

const STAGE_DELAY_MS = 280;

/**
 * MODULE 2 - AI-Based User Authentication.
 *
 * Walks visibly through the five pipeline stages, then shows the comparison
 * between the stored profile and the current session plus the scores.
 */
export default function AiAuthentication() {
  const {
    profile,
    lastSession,
    sessions,
    runAuthTest,
    simulateSuspicious,
    simulateBorderline,
    captureReady,
    monitoring,
  } = useApp();

  const [running, setRunning] = useState(false);
  const [stage, setStage] = useState(-1);
  const timerRef = useRef(null);

  useEffect(
    () => () => {
      if (timerRef.current) window.clearTimeout(timerRef.current);
    },
    [],
  );

  /** Animates the five stages, then commits the session. */
  const execute = useCallback(
    (action) => {
      if (running || !profile) return;
      setRunning(true);
      setStage(0);

      let i = 0;
      const step = () => {
        i += 1;
        if (i < 5) {
          setStage(i);
          timerRef.current = window.setTimeout(step, STAGE_DELAY_MS);
        } else {
          action();
          setRunning(false);
          setStage(-1);
        }
      };
      timerRef.current = window.setTimeout(step, STAGE_DELAY_MS);
    },
    [running, profile],
  );

  const score = lastSession ? lastSession.confidenceScore : null;

  return (
    <div className="stack">
      <DemoBanner>
        <strong>Simulated AI/ML authentication demo.</strong> The &quot;model&quot; is a
        deterministic weighted-similarity function (see the formula below), chosen because every
        number it produces can be verified by hand during a viva. It is not a trained neural
        network and no training data is involved.
      </DemoBanner>

      {!profile && (
        <Card
          title="No behaviour profile to compare against"
          actions={
            <Link className="btn btn--accent" to="/profile">
              <IconUser size={14} /> Create profile
            </Link>
          }
        >
          <p className="text-sm">
            Module 2 compares the current session against a stored profile. Enroll one on the{' '}
            <strong>User Profile</strong> page first.
          </p>
        </Card>
      )}

      {/* ---------- pipeline ---------- */}
      <Card
        title="Authentication Pipeline"
        hint="Behavioural Data -> Pre-processing & Feature Extraction -> AI/ML Model -> Behaviour Comparison -> Risk / Confidence Score"
        actions={
          running ? (
            <StatusBadge tone="info" pulse>
              Evaluating stage {stage + 1} of 5
            </StatusBadge>
          ) : (
            lastSession && <StatusBadge tone={lastSession.tone}>{lastSession.status}</StatusBadge>
          )
        }
      >
        <PipelineFlow activeIndex={running ? stage : -1} completed={!running && !!lastSession} />
      </Card>

      {/* ---------- actions ---------- */}
      <Card
        title="Run the model"
        hint={
          captureReady
            ? 'A live captured session is available and will be used'
            : 'Not enough live data captured - a simulated session will be generated instead'
        }
      >
        <div className="row">
          <button
            type="button"
            className="btn btn--accent"
            onClick={() => execute(() => runAuthTest('auto'))}
            disabled={!profile || running}
          >
            <IconPlay size={14} /> Run Authentication Test
          </button>

          <button
            type="button"
            className="btn"
            onClick={() => execute(simulateBorderline)}
            disabled={!profile || running}
          >
            <IconShield size={14} /> Simulate Borderline Session
          </button>

          <button
            type="button"
            className="btn btn--danger"
            onClick={() => execute(simulateSuspicious)}
            disabled={!profile || running}
          >
            <IconAlert size={14} /> Simulate Suspicious Activity
          </button>

          <StatusBadge tone={monitoring ? 'good' : 'neutral'} pulse={monitoring}>
            {monitoring ? 'Live capture running' : 'Live capture off'}
          </StatusBadge>
        </div>

        <p className="small muted mt-10">
          <strong>Run Authentication Test</strong> uses the real captured session when Module 1 has
          collected enough events; otherwise it generates a genuine-user session. The other two
          buttons always generate data, so the medium-risk and high-risk branches can be shown on
          demand.
        </p>
      </Card>

      {/* ---------- result ---------- */}
      <div className="grid grid--aside">
        <Card title="Risk / Confidence Score" hint="Stage 5 output">
          <ConfidenceScore score={score} />
          <div className="mt-14">
            <RiskIndicator score={score} />
          </div>
        </Card>

        <div className="stack">
          <div className="grid grid--3">
            <MetricCard
              label="Similarity Score"
              value={lastSession ? lastSession.similarityScore : '--'}
              unit="/100"
              icon="activity"
              footnote="Unweighted mean of the six feature matches"
            />
            <MetricCard
              label="Confidence Score"
              value={score === null ? '--' : score}
              unit="/100"
              icon="gauge"
              footnote="Weighted model output - drives the decision"
            />
            <MetricCard
              label="Features Outside Tolerance"
              value={lastSession ? `${lastSession.featuresOutsideTolerance}/6` : '--'}
              icon="cpu"
              footnote={
                lastSession?.weakestFeature
                  ? `Weakest: ${lastSession.weakestFeature.label}`
                  : 'No session evaluated yet'
              }
            />
          </div>

          <Card
            title="Per-feature match against the profile"
            hint="Bars below 70% are the features that pulled the confidence score down"
          >
            <SimilarityChart breakdown={lastSession?.breakdown || []} />
          </Card>
        </div>
      </div>

      {/* ---------- comparison table ---------- */}
      <Card
        title="Behaviour Comparison"
        hint={
          lastSession
            ? `Session ${lastSession.id} - ${lastSession.source} - evaluated ${timeAgo(lastSession.timestamp)}`
            : 'Stage 4: stored profile vs current session'
        }
        actions={
          lastSession && (
            <>
              <StatusBadge tone="info">{lastSession.mode} session</StatusBadge>
              <span className="small muted">{formatDateTime(lastSession.timestamp)}</span>
            </>
          )
        }
        flush
      >
        {lastSession ? (
          <BehaviorDataTable rows={lastSession.breakdown} variant="full" />
        ) : (
          <p className="empty">Run an authentication test to populate the comparison table.</p>
        )}
      </Card>

      {/* ---------- algorithm + thresholds ---------- */}
      <div className="grid grid--2">
        <Card title="How the simulated model scores a session" hint="The whole algorithm, in five lines">
          <div className="formula">
{`d_i = | current_i - baseline_i |

s_i = max(0, 1 - d_i / (2 x tolerance_i))

similarity  = 100 x mean(s_i)
confidence  = 100 x SUM(w_i x s_i)        [SUM(w_i) = 1]

risk        = low      if confidence >= 70
              medium   if confidence >= 40
              high     otherwise`}
          </div>
          <div className="prose mt-14">
            <h4>Reading it in one sentence</h4>
            <p>
              A feature scores 1.00 when it exactly matches the enrolled baseline, 0.50 when it sits
              right on the edge of its tolerance band, and 0.00 once it has drifted twice the
              tolerance away; those six scores are combined using fixed importance weights into a
              single 0-100 confidence value, which the threshold rule turns into a decision.
            </p>
          </div>
        </Card>

        <div className="stack">
          <Card title="Threshold logic" flush>
            <div className="table-wrap">
              <table className="data">
                <thead>
                  <tr>
                    <th>Confidence score</th>
                    <th>Risk level</th>
                    <th>Authentication status</th>
                  </tr>
                </thead>
                <tbody>
                  {THRESHOLD_ROWS.map((r) => (
                    <tr key={r.range}>
                      <td className="num feature-name">{r.range}</td>
                      <td>
                        <StatusBadge tone={r.tone}>{r.risk}</StatusBadge>
                      </td>
                      <td>{r.status}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>

          <Card
            title="Session history"
            hint="Last evaluations stored in localStorage"
            actions={
              <Link className="btn btn--sm" to="/alerts">
                Security alerts <IconArrowRight size={13} />
              </Link>
            }
            flush
          >
            {sessions.length === 0 ? (
              <p className="empty">No sessions evaluated yet.</p>
            ) : (
              <div className="table-wrap">
                <table className="data">
                  <thead>
                    <tr>
                      <th>Time</th>
                      <th>Type</th>
                      <th>Similarity</th>
                      <th>Confidence</th>
                      <th>Result</th>
                    </tr>
                  </thead>
                  <tbody>
                    {sessions.slice(0, 8).map((s) => (
                      <tr key={s.id}>
                        <td className="nowrap">
                          <div>{timeAgo(s.timestamp)}</div>
                          <div className="sub mono">{s.id}</div>
                        </td>
                        <td className="nowrap">
                          <div>{s.mode}</div>
                          <div className="sub">{s.source}</div>
                        </td>
                        <td className="num">{s.similarityScore}</td>
                        <td className="num" style={{ fontWeight: 650 }}>{s.confidenceScore}</td>
                        <td>
                          <StatusBadge tone={s.tone}>{s.status}</StatusBadge>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </Card>
        </div>
      </div>
    </div>
  );
}
