import { Link } from 'react-router-dom';

import ActivityChart from '../components/ActivityChart';
import ActivityList from '../components/ActivityList';
import Card from '../components/Card';
import ConfidenceScore from '../components/ConfidenceScore';
import ConfidenceTrendChart from '../components/ConfidenceTrendChart';
import DemoBanner from '../components/DemoBanner';
import MetricCard from '../components/MetricCard';
import PipelineFlow from '../components/PipelineFlow';
import RiskIndicator from '../components/RiskIndicator';
import SecurityAlert, { NoAlerts } from '../components/SecurityAlert';
import StatusBadge from '../components/StatusBadge';
import { IconAlert, IconArrowRight, IconPlay, IconStop, IconUser } from '../components/Icons';
import { useApp } from '../context/AppContext';
import { formatDuration, timeAgo } from '../utils/formatters';

/**
 * MODULE 3 - Authentication Dashboard.
 * A single screen overview of the whole system: status, score, live activity,
 * recent activities and security alerts.
 */
export default function Dashboard() {
  const {
    profile,
    monitoring,
    startMonitoring,
    stopMonitoring,
    rawMetrics,
    timeline,
    sessions,
    lastSession,
    confidenceTrend,
    runAuthTest,
    simulateSuspicious,
    alerts,
    openAlerts,
    activities,
  } = useApp();

  const score = lastSession ? lastSession.confidenceScore : null;
  const latestAlert = alerts[0] || null;

  return (
    <div className="stack">
      <DemoBanner>
        <strong>Demo / simulation.</strong> Every value on this dashboard comes from the browser
        session or from generated sample data, and the confidence score is produced by a transparent
        weighted-similarity formula - not by a trained machine-learning model.
      </DemoBanner>

      {!profile && (
        <Card
          title="No behaviour profile enrolled"
          hint="Module 2 needs a stored profile before it can compare anything"
          actions={
            <Link className="btn btn--accent" to="/profile">
              <IconUser size={14} /> Go to User Profile
            </Link>
          }
        >
          <p className="text-sm">
            Open <strong>User Profile</strong> and press{' '}
            <strong>Create / Update Behaviour Profile</strong> to enroll a sample baseline. The
            profile is saved in <code>localStorage</code>, so it survives a page reload during your
            presentation.
          </p>
        </Card>
      )}

      {/* ---------- system flow ---------- */}
      <Card
        title="System data flow"
        hint="User -> Behavioural Data Capture -> Pre-processing -> AI/ML Authentication -> Behaviour Comparison -> Risk / Confidence Score -> Dashboard"
      >
        <PipelineFlow completed={!!lastSession} compact />
      </Card>

      {/* ---------- KPI row ---------- */}
      <div className="grid grid--4">
        <MetricCard
          label="Confidence Score"
          value={score === null ? '--' : score}
          unit="/100"
          icon="gauge"
          footnote={lastSession ? lastSession.riskLabel : 'No session evaluated yet'}
        />
        <MetricCard
          label="Authentication Status"
          value={lastSession ? lastSession.status.split(' ')[0] : '--'}
          icon={lastSession && lastSession.riskLevel === 'low' ? 'shieldCheck' : 'shield'}
          footnote={lastSession ? lastSession.status : 'Run an authentication test'}
        />
        <MetricCard
          label="Open Security Alerts"
          value={openAlerts.length}
          icon="alert"
          footnote={openAlerts.length === 0 ? 'No alerts' : 'Pending investigation'}
        />
        <MetricCard
          label="Sessions Evaluated"
          value={sessions.length}
          icon="cpu"
          footnote={lastSession ? `Last test ${timeAgo(lastSession.timestamp)}` : 'Module 2 idle'}
        />
      </div>

      {/* ---------- main row ---------- */}
      <div className="grid grid--main">
        <div className="stack">
          <Card
            title="Live Activity Monitor"
            hint="Behavioural events captured per second in the current session"
            actions={
              <>
                <StatusBadge tone={monitoring ? 'good' : 'neutral'} pulse={monitoring}>
                  {monitoring ? 'Capturing' : 'Idle'}
                </StatusBadge>
                {monitoring ? (
                  <button type="button" className="btn btn--sm" onClick={stopMonitoring}>
                    <IconStop size={13} /> Stop
                  </button>
                ) : (
                  <button type="button" className="btn btn--sm btn--accent" onClick={startMonitoring}>
                    <IconPlay size={13} /> Start Monitoring
                  </button>
                )}
              </>
            }
          >
            <ActivityChart data={timeline} />
            <div className="grid grid--4 mt-14">
              <MetricCard label="Session Duration" value={formatDuration(rawMetrics.durationSec)} icon="clock" live={monitoring} />
              <MetricCard label="Mouse Events" value={rawMetrics.mouseMoves} icon="mouse" live={monitoring} />
              <MetricCard label="Key Events" value={rawMetrics.keyPresses} icon="keyboard" live={monitoring} />
              <MetricCard label="Clicks / Scrolls" value={`${rawMetrics.clicks} / ${rawMetrics.scrolls}`} icon="click" live={monitoring} />
            </div>
          </Card>

          <Card
            title="Confidence Score Trend"
            hint="Confidence of the last authentication tests, with the 70 and 40 thresholds marked"
          >
            <ConfidenceTrendChart data={confidenceTrend} />
          </Card>
        </div>

        <div className="stack">
          <Card title="Risk / Confidence Score" hint="Output of the simulated AI/ML model">
            <ConfidenceScore score={score} />
            <div className="mt-14">
              <RiskIndicator score={score} />
            </div>
          </Card>

          <Card title="Demo Controls" hint="Everything needed for the project review">
            <div className="stack" style={{ gap: 9 }}>
              <button
                type="button"
                className="btn btn--accent btn--block"
                onClick={() => runAuthTest('auto')}
                disabled={!profile}
              >
                <IconPlay size={14} /> Run Authentication Test
              </button>
              <button
                type="button"
                className="btn btn--danger btn--block"
                onClick={simulateSuspicious}
                disabled={!profile}
              >
                <IconAlert size={14} /> Simulate Suspicious Activity
              </button>
              <Link className="btn btn--block" to="/authentication">
                Open AI Authentication <IconArrowRight size={14} />
              </Link>
              {!profile && <p className="small muted">Enroll a behaviour profile first to enable the tests.</p>}
            </div>
          </Card>
        </div>
      </div>

      {/* ---------- bottom row ---------- */}
      <div className="grid grid--2">
        <Card
          title="Recent Activities"
          hint="Session events recorded by the prototype"
          flush
        >
          <ActivityList activities={activities} limit={7} />
        </Card>

        <Card
          title="Security Alerts"
          hint="Generated automatically when confidence drops below 70"
          actions={
            alerts.length > 0 && (
              <Link className="btn btn--sm" to="/alerts">
                View all <IconArrowRight size={13} />
              </Link>
            )
          }
          flush={alerts.length === 0}
        >
          {latestAlert ? <SecurityAlert alert={latestAlert} compact /> : <NoAlerts />}
        </Card>
      </div>
    </div>
  );
}
