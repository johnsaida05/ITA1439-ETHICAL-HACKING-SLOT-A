import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';

import ActivityChart from '../components/ActivityChart';
import BehaviorDataTable from '../components/BehaviorDataTable';
import Card from '../components/Card';
import DemoBanner from '../components/DemoBanner';
import MetricCard from '../components/MetricCard';
import PipelineFlow from '../components/PipelineFlow';
import StatusBadge from '../components/StatusBadge';
import { IconArrowRight, IconPlay, IconRefresh, IconStop } from '../components/Icons';
import { FEATURES } from '../data/constants';
import { useApp } from '../context/AppContext';
import { formatDuration, formatNumber, formatDateTime, round } from '../utils/formatters';

/** Sample application-usage rows. Clearly labelled as demo data in the UI. */
const APP_USAGE = [
  { app: 'BioAuth Web Console', share: 0.62, focusEvents: 18, note: 'Current application' },
  { app: 'Reports Module', share: 0.21, focusEvents: 6, note: 'Opened earlier in the session' },
  { app: 'Mail Client', share: 0.17, focusEvents: 4, note: 'Background' },
];

/**
 * MODULE 1 - Behavioural Data Capture.
 *
 * Two data sources, both visible to the audience:
 *   1. real browser events (keydown/keyup timings, mouse path, clicks, scrolls)
 *   2. an optional 1 Hz simulator that keeps the numbers moving when nobody
 *      is touching the machine - essential during a presentation.
 */
export default function BehaviourCapture() {
  const {
    monitoring,
    startMonitoring,
    stopMonitoring,
    resetCapture,
    autoSimulate,
    setAutoSimulate,
    rawMetrics,
    liveFeatures,
    captureReady,
    timeline,
    profile,
  } = useApp();

  const [typed, setTyped] = useState('');

  const sessionId = useMemo(
    () => (rawMetrics.startedAt ? `SES-${new Date(rawMetrics.startedAt).getTime().toString(36).toUpperCase()}` : null),
    [rawMetrics.startedAt],
  );

  /* Live comparison rows: captured value against the enrolled baseline. */
  const liveRows = useMemo(
    () =>
      FEATURES.map((f) => {
        const baseline = profile?.baseline?.[f.key] ?? f.baseline;
        const tolerance = profile?.tolerance?.[f.key] ?? f.tolerance;
        const current = liveFeatures[f.key] ?? 0;
        return {
          key: f.key,
          label: f.label,
          group: f.group,
          unit: f.unit,
          decimals: f.decimals,
          weight: f.weight,
          baseline: round(baseline, f.decimals),
          tolerance,
          current: round(current, f.decimals),
          deviation: round(current - baseline, f.decimals),
          withinTolerance: Math.abs(current - baseline) <= tolerance,
        };
      }),
    [liveFeatures, profile],
  );

  const totalEvents =
    rawMetrics.keyPresses + rawMetrics.mouseMoves + rawMetrics.clicks + rawMetrics.scrolls;

  return (
    <div className="stack">
      <DemoBanner>
        <strong>Demo / simulation.</strong> Keystroke timings, mouse path length, clicks and scrolls
        are read from real browser events in this tab. With{' '}
        <strong>Auto-simulate activity</strong> switched on, synthetic events are also added once per
        second so the metrics keep changing while you explain the slide. No data leaves the browser.
      </DemoBanner>

      <Card title="Capture pipeline position" hint="Module 1 feeds stages 1 and 2 of the system flow">
        <PipelineFlow activeIndex={monitoring ? 1 : 0} compact />
      </Card>

      {/* ---------- controls ---------- */}
      <Card
        title="Monitoring Control"
        hint="Start capturing, then type and move the mouse to generate real behavioural data"
        actions={
          <StatusBadge tone={monitoring ? 'good' : 'neutral'} pulse={monitoring}>
            {monitoring ? 'Capturing events' : 'Stopped'}
          </StatusBadge>
        }
      >
        <div className="row">
          {monitoring ? (
            <button type="button" className="btn btn--danger" onClick={stopMonitoring}>
              <IconStop size={14} /> Stop Monitoring
            </button>
          ) : (
            <button type="button" className="btn btn--accent" onClick={startMonitoring}>
              <IconPlay size={14} /> Start Monitoring
            </button>
          )}

          <button type="button" className="btn" onClick={resetCapture} disabled={monitoring}>
            <IconRefresh size={14} /> Clear captured data
          </button>

          <label className="switch" style={{ marginLeft: 'auto' }}>
            <input
              type="checkbox"
              checked={autoSimulate}
              onChange={(e) => setAutoSimulate(e.target.checked)}
            />
            <span className="switch__track" />
            Auto-simulate activity
          </label>
        </div>

        <div className="mt-14">
          <StatusBadge tone={captureReady ? 'good' : 'warning'}>
            {captureReady
              ? 'Enough data captured for authentication'
              : 'Collecting - needs 5 s, 12 key events and 25 mouse events'}
          </StatusBadge>
        </div>
      </Card>

      {/* ---------- live metrics ---------- */}
      <div>
        <h3 className="section-title">Captured behaviour metrics</h3>
        <div className="grid grid--3">
          <MetricCard
            label="Typing Speed"
            value={formatNumber(liveFeatures.typingSpeed, 1)}
            unit="WPM"
            icon="keyboard"
            live={monitoring}
            footnote={`${rawMetrics.charsTyped} characters typed`}
          />
          <MetricCard
            label="Avg Key Press Duration"
            value={formatNumber(liveFeatures.keyHoldTime, 0)}
            unit="ms"
            icon="keyboard"
            live={monitoring}
            footnote={`${rawMetrics.holdTimeSamples} hold-time samples`}
          />
          <MetricCard
            label="Avg Flight Time"
            value={formatNumber(liveFeatures.flightTime, 0)}
            unit="ms"
            icon="keyboard"
            live={monitoring}
            footnote="Gap between consecutive key presses"
          />
          <MetricCard
            label="Mouse Movement Count"
            value={rawMetrics.mouseMoves}
            icon="mouse"
            live={monitoring}
            footnote={`${formatNumber(liveFeatures.mouseSpeed, 0)} px/s average speed`}
          />
          <MetricCard
            label="Click Count"
            value={rawMetrics.clicks}
            icon="click"
            live={monitoring}
            footnote={`${formatNumber(liveFeatures.clickRate, 1)} clicks/min`}
          />
          <MetricCard
            label="Scroll Count"
            value={rawMetrics.scrolls}
            icon="scroll"
            live={monitoring}
            footnote={`${formatNumber(liveFeatures.scrollRate, 1)} scrolls/min`}
          />
        </div>
      </div>

      {/* ---------- chart + input pads ---------- */}
      <div className="grid grid--main">
        <Card title="Live Activity Monitor" hint="Events per second over the last 30 seconds">
          <ActivityChart data={timeline} />
        </Card>

        <div className="stack">
          <Card
            title="Keystroke Dynamics Capture"
            hint="Type here while monitoring is on - key hold and flight times are measured from these events"
          >
            <textarea
              className="capture-pad"
              value={typed}
              disabled={!monitoring}
              placeholder={
                monitoring
                  ? 'Start typing a few sentences so the model has keystroke timings to work with...'
                  : 'Press "Start Monitoring" to enable keystroke capture.'
              }
              onChange={(e) => setTyped(e.target.value)}
            />
            <p className="small muted mt-6">
              The text itself is never stored or analysed - only the timing between key events is used.
            </p>
          </Card>

          <Card title="Scroll Pattern Capture" hint="Scroll inside this box to generate scroll events">
            <div className="scroll-pad">
              <p>
                Behavioural biometrics identify a person by <em>how</em> they interact with a device
                rather than by a fingerprint or a face scan. The three families of signal used in
                this prototype are keystroke dynamics, mouse dynamics, and click/scroll rhythm.
              </p>
              <p className="mt-10">
                Keystroke dynamics measure dwell time (how long a key is held) and flight time (the
                gap between two key presses). Both are stable for an individual and hard to imitate.
              </p>
              <p className="mt-10">
                Mouse dynamics describe the speed and smoothness of pointer movement. Click and
                scroll rhythm capture how quickly a user navigates through a page.
              </p>
              <p className="mt-10">
                Keep scrolling - every scroll event here is counted by Module 1 and used to compute
                the scroll-rate feature.
              </p>
            </div>
          </Card>
        </div>
      </div>

      {/* ---------- session + application usage ---------- */}
      <div className="grid grid--2">
        <Card title="Session Information" hint="Metadata attached to the captured session">
          <div className="kv">
            <div className="kv__cell">
              <div className="kv__k">Session ID</div>
              <div className="kv__v mono" style={{ fontSize: 12.5 }}>{sessionId || 'Not started'}</div>
            </div>
            <div className="kv__cell">
              <div className="kv__k">Started at</div>
              <div className="kv__v" style={{ fontSize: 12.5 }}>
                {rawMetrics.startedAt ? formatDateTime(rawMetrics.startedAt) : '--'}
              </div>
            </div>
            <div className="kv__cell">
              <div className="kv__k">Session duration</div>
              <div className="kv__v mono">{formatDuration(rawMetrics.durationSec)}</div>
            </div>
            <div className="kv__cell">
              <div className="kv__k">Total events captured</div>
              <div className="kv__v mono">{totalEvents}</div>
            </div>
            <div className="kv__cell">
              <div className="kv__k">Registered device</div>
              <div className="kv__v" style={{ fontSize: 12.5 }}>{profile?.device || 'No profile enrolled'}</div>
            </div>
            <div className="kv__cell">
              <div className="kv__k">Data source</div>
              <div className="kv__v" style={{ fontSize: 12.5 }}>
                {autoSimulate ? 'Browser events + simulator' : 'Browser events only'}
              </div>
            </div>
          </div>
        </Card>

        <Card title="Application Usage" hint="Sample data - included to show the feature in the architecture">
          <div className="table-wrap">
            <table className="data">
              <thead>
                <tr>
                  <th>Application</th>
                  <th>Share of session</th>
                  <th>Focus events</th>
                </tr>
              </thead>
              <tbody>
                {APP_USAGE.map((row) => (
                  <tr key={row.app}>
                    <td>
                      <div className="feature-name">{row.app}</div>
                      <div className="sub">{row.note}</div>
                    </td>
                    <td>
                      <div className="row" style={{ gap: 8, flexWrap: 'nowrap' }}>
                        <div className="bar" style={{ width: 90, flex: '0 0 90px' }}>
                          <div className="bar__fill" style={{ width: `${row.share * 100}%` }} />
                        </div>
                        <span className="num">{Math.round(row.share * 100)}%</span>
                      </div>
                    </td>
                    <td className="num">{row.focusEvents}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <p className="small muted mt-10">
            Application usage is not measurable from a browser tab, so these three rows are fixed
            sample values kept for architectural completeness.
          </p>
        </Card>
      </div>

      {/* ---------- extracted features ---------- */}
      <Card
        title="Extracted Features vs Enrolled Profile"
        hint="Stage 2 output: raw events reduced to six numeric features"
        actions={
          <Link className="btn btn--sm btn--accent" to="/authentication">
            Continue to AI Authentication <IconArrowRight size={13} />
          </Link>
        }
        flush
      >
        {profile ? (
          <BehaviorDataTable rows={liveRows} variant="live" />
        ) : (
          <p className="empty">
            No behaviour profile enrolled yet - create one on the <strong>User Profile</strong> page
            to compare the captured session against a baseline.
          </p>
        )}
      </Card>
    </div>
  );
}
