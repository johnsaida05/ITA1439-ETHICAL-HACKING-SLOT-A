/**
 * Icons.jsx - a tiny inline-SVG icon set.
 * Inline SVG keeps the project dependency-free and means icons inherit the
 * surrounding text colour, so status colours never get out of sync.
 */

const base = {
  width: 16,
  height: 16,
  viewBox: '0 0 24 24',
  fill: 'none',
  stroke: 'currentColor',
  strokeWidth: 1.9,
  strokeLinecap: 'round',
  strokeLinejoin: 'round',
};

function Svg({ size = 16, children, ...rest }) {
  return (
    <svg {...base} width={size} height={size} aria-hidden="true" focusable="false" {...rest}>
      {children}
    </svg>
  );
}

export const IconShield = (p) => (
  <Svg {...p}>
    <path d="M12 3l7 3v5.5c0 4.2-2.9 7.9-7 9.5-4.1-1.6-7-5.3-7-9.5V6l7-3z" />
  </Svg>
);

export const IconShieldCheck = (p) => (
  <Svg {...p}>
    <path d="M12 3l7 3v5.5c0 4.2-2.9 7.9-7 9.5-4.1-1.6-7-5.3-7-9.5V6l7-3z" />
    <path d="M9 12l2 2 4-4" />
  </Svg>
);

export const IconDashboard = (p) => (
  <Svg {...p}>
    <rect x="3" y="3" width="7.5" height="7.5" rx="1.5" />
    <rect x="13.5" y="3" width="7.5" height="7.5" rx="1.5" />
    <rect x="3" y="13.5" width="7.5" height="7.5" rx="1.5" />
    <rect x="13.5" y="13.5" width="7.5" height="7.5" rx="1.5" />
  </Svg>
);

export const IconActivity = (p) => (
  <Svg {...p}>
    <path d="M3 12h4l2.5-7 4 14L16.5 12H21" />
  </Svg>
);

export const IconCpu = (p) => (
  <Svg {...p}>
    <rect x="7" y="7" width="10" height="10" rx="2" />
    <path d="M12 2v3M12 19v3M2 12h3M19 12h3M5.5 5.5l2 2M16.5 16.5l2 2M18.5 5.5l-2 2M7.5 16.5l-2 2" />
  </Svg>
);

export const IconAlert = (p) => (
  <Svg {...p}>
    <path d="M10.3 3.8L2.6 17a2 2 0 001.7 3h15.4a2 2 0 001.7-3L13.7 3.8a2 2 0 00-3.4 0z" />
    <path d="M12 9v4M12 17h.01" />
  </Svg>
);

export const IconUser = (p) => (
  <Svg {...p}>
    <circle cx="12" cy="8" r="3.6" />
    <path d="M4.5 20c0-3.6 3.4-5.6 7.5-5.6s7.5 2 7.5 5.6" />
  </Svg>
);

export const IconInfo = (p) => (
  <Svg {...p}>
    <circle cx="12" cy="12" r="9" />
    <path d="M12 11v5M12 8h.01" />
  </Svg>
);

export const IconKeyboard = (p) => (
  <Svg {...p}>
    <rect x="2" y="6" width="20" height="12" rx="2" />
    <path d="M6 10h.01M10 10h.01M14 10h.01M18 10h.01M8 14h8" />
  </Svg>
);

export const IconMouse = (p) => (
  <Svg {...p}>
    <rect x="7" y="3" width="10" height="18" rx="5" />
    <path d="M12 7v3" />
  </Svg>
);

export const IconClick = (p) => (
  <Svg {...p}>
    <path d="M9 4v8" />
    <path d="M9 12V9.5a1.5 1.5 0 013 0V11a1.5 1.5 0 013 0v1a1.5 1.5 0 013 0v4a4 4 0 01-4 4h-2.2a4 4 0 01-3.3-1.8L6 15" />
  </Svg>
);

export const IconScroll = (p) => (
  <Svg {...p}>
    <path d="M12 4v16" />
    <path d="M8 8l4-4 4 4M8 16l4 4 4-4" />
  </Svg>
);

export const IconClock = (p) => (
  <Svg {...p}>
    <circle cx="12" cy="12" r="9" />
    <path d="M12 7.5V12l3 2" />
  </Svg>
);

export const IconGauge = (p) => (
  <Svg {...p}>
    <path d="M4 18a8 8 0 1116 0" />
    <path d="M12 18l4.2-5" />
  </Svg>
);

export const IconFile = (p) => (
  <Svg {...p}>
    <path d="M14 3H7a2 2 0 00-2 2v14a2 2 0 002 2h10a2 2 0 002-2V8l-5-5z" />
    <path d="M14 3v5h5" />
  </Svg>
);

export const IconEdit = (p) => (
  <Svg {...p}>
    <path d="M12 20h8" />
    <path d="M16.5 3.5a2.1 2.1 0 013 3L7 19l-4 1 1-4 12.5-12.5z" />
  </Svg>
);

export const IconLogin = (p) => (
  <Svg {...p}>
    <path d="M14 3h4a2 2 0 012 2v14a2 2 0 01-2 2h-4" />
    <path d="M10 17l-5-5 5-5M5 12h9" />
  </Svg>
);

export const IconLogout = (p) => (
  <Svg {...p}>
    <path d="M10 3H6a2 2 0 00-2 2v14a2 2 0 002 2h4" />
    <path d="M15 17l5-5-5-5M20 12h-9" />
  </Svg>
);

export const IconPlay = (p) => (
  <Svg {...p}>
    <path d="M7 4.5l12 7.5-12 7.5z" />
  </Svg>
);

export const IconStop = (p) => (
  <Svg {...p}>
    <rect x="6" y="6" width="12" height="12" rx="2" />
  </Svg>
);

export const IconRefresh = (p) => (
  <Svg {...p}>
    <path d="M20 11a8 8 0 10-2.5 6.3" />
    <path d="M20 5v6h-6" />
  </Svg>
);

export const IconArrowRight = (p) => (
  <Svg {...p}>
    <path d="M5 12h14M13 6l6 6-6 6" />
  </Svg>
);

export const IconCheck = (p) => (
  <Svg {...p}>
    <path d="M5 13l4.5 4.5L19 7" />
  </Svg>
);

export const IconBook = (p) => (
  <Svg {...p}>
    <path d="M4 5a2 2 0 012-2h9a2 2 0 012 2v16H6a2 2 0 01-2-2V5z" />
    <path d="M17 3h1a2 2 0 012 2v14a2 2 0 01-2 2h-1" />
  </Svg>
);

export const IconDatabase = (p) => (
  <Svg {...p}>
    <ellipse cx="12" cy="6" rx="8" ry="3" />
    <path d="M4 6v12c0 1.7 3.6 3 8 3s8-1.3 8-3V6" />
    <path d="M4 12c0 1.7 3.6 3 8 3s8-1.3 8-3" />
  </Svg>
);

/** Name -> component map used by the activity feed and alert rows. */
export const ICON_BY_NAME = {
  shield: IconShield,
  shieldCheck: IconShieldCheck,
  activity: IconActivity,
  alert: IconAlert,
  user: IconUser,
  info: IconInfo,
  file: IconFile,
  edit: IconEdit,
  login: IconLogin,
  logout: IconLogout,
  keyboard: IconKeyboard,
  mouse: IconMouse,
  click: IconClick,
  scroll: IconScroll,
  clock: IconClock,
  gauge: IconGauge,
  cpu: IconCpu,
  database: IconDatabase,
};

export function Icon({ name, size = 16, ...rest }) {
  const Cmp = ICON_BY_NAME[name] || IconInfo;
  return <Cmp size={size} {...rest} />;
}
