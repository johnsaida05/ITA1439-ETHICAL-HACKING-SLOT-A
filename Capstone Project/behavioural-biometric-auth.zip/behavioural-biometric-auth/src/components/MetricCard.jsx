import { Icon } from './Icons';

/**
 * MetricCard - one captured behavioural metric (Module 1) or one dashboard KPI.
 * A stat tile rather than a chart: a single number is the whole story.
 */
export default function MetricCard({
  label,
  value,
  unit,
  icon = 'info',
  footnote,
  live = false,
}) {
  return (
    <article className={`metric ${live ? 'metric--live' : ''}`}>
      <div className="metric__top">
        <span className="metric__icon">
          <Icon name={icon} size={17} />
        </span>
        <span className="metric__label">{label}</span>
      </div>

      <div className="metric__value mono">
        {value}
        {unit && <span className="metric__unit">{unit}</span>}
      </div>

      {footnote && <div className="metric__foot">{footnote}</div>}
    </article>
  );
}
