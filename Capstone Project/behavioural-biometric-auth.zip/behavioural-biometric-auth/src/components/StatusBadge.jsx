/** StatusBadge - small pill with a colour dot + text label. */
export default function StatusBadge({ tone = 'neutral', children, pulse = false }) {
  const safeTone = ['good', 'warning', 'critical', 'info', 'neutral'].includes(tone) ? tone : 'neutral';
  const dotTone = safeTone === 'info' ? 'neutral' : safeTone;

  return (
    <span className={`badge badge--${safeTone}`}>
      <span className={`dot dot--${dotTone} ${pulse ? 'pulse' : ''}`} />
      {children}
    </span>
  );
}
