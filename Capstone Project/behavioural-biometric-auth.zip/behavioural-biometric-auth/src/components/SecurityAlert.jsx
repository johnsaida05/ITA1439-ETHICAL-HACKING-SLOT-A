import { IconAlert, IconShieldCheck, IconCheck } from './Icons';
import StatusBadge from './StatusBadge';
import { formatDateTime, timeAgo } from '../utils/formatters';

/**
 * SecurityAlert - one generated alert row (Module 3).
 * Pass `compact` for the dashboard summary; the full form shows the
 * admin / security-team investigation block.
 */
export default function SecurityAlert({ alert, compact = false, onAcknowledge }) {
  if (!alert) return null;

  const critical = alert.severity === 'critical';

  return (
    <article className={`alert alert--${critical ? 'critical' : 'warning'}`}>
      <span style={{ flex: '0 0 18px', marginTop: 2, color: 'inherit' }}>
        <IconAlert size={18} />
      </span>

      <div style={{ minWidth: 0, flex: 1 }}>
        <div className="row" style={{ gap: 8 }}>
          <h4 className="alert__title">{alert.title}</h4>
          <StatusBadge tone={critical ? 'critical' : 'warning'}>
            {critical ? 'High Risk' : 'Medium Risk'}
          </StatusBadge>
          {alert.acknowledged && <StatusBadge tone="good">Acknowledged</StatusBadge>}
        </div>

        <p className="alert__text">{alert.message}</p>

        {!compact && (
          <>
            <p className="alert__text">{alert.reason}</p>

            <div className="kv mt-10">
              <div className="kv__cell">
                <div className="kv__k">Confidence score</div>
                <div className="kv__v mono">{alert.confidenceScore}/100</div>
              </div>
              <div className="kv__cell">
                <div className="kv__k">Features outside tolerance</div>
                <div className="kv__v mono">{alert.featuresOutsideTolerance} of 6</div>
              </div>
              <div className="kv__cell">
                <div className="kv__k">Automated action</div>
                <div className="kv__v">{alert.action}</div>
              </div>
              <div className="kv__cell">
                <div className="kv__k">Session reference</div>
                <div className="kv__v mono" style={{ fontSize: 12 }}>{alert.sessionId}</div>
              </div>
            </div>

            <div className="kv mt-10">
              <div className="kv__cell">
                <div className="kv__k">Admin / Security team</div>
                <div className="kv__v">{alert.assignedTo}</div>
              </div>
              <div className="kv__cell">
                <div className="kv__k">Investigation status</div>
                <div className="kv__v">
                  {alert.acknowledged ? 'Reviewed by security team' : alert.investigationStatus}
                </div>
              </div>
            </div>
          </>
        )}

        <div className="row mt-10" style={{ gap: 10 }}>
          <span className="alert__meta">
            {timeAgo(alert.timestamp)} &middot; {formatDateTime(alert.timestamp)}
          </span>
          {!compact && onAcknowledge && !alert.acknowledged && (
            <button type="button" className="btn btn--sm" onClick={() => onAcknowledge(alert.id)}>
              <IconCheck size={13} /> Mark as reviewed
            </button>
          )}
        </div>
      </div>
    </article>
  );
}

/** The "No Alerts" state - shown whenever the alert log is empty. */
export function NoAlerts({ children }) {
  return (
    <div className="empty">
      <div className="empty__icon">
        <IconShieldCheck size={30} />
      </div>
      <p style={{ fontWeight: 600, color: 'var(--good-text)' }}>No Alerts</p>
      <p className="small muted mt-6">
        {children || 'All evaluated sessions are inside the low-risk band (confidence 70 or above).'}
      </p>
    </div>
  );
}
