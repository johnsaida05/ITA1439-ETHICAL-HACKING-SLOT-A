import {
  CartesianGrid,
  Line,
  LineChart,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';

import ChartTooltip from './ChartTooltip';
import { CHART } from '../utils/chartUtils';

/**
 * ConfidenceTrendChart - confidence score across the last authentication tests.
 * Single series, so the card title names it and no legend box is needed.
 * The 70 and 40 threshold lines are drawn in so the bands are readable.
 */
export default function ConfidenceTrendChart({ data = [] }) {
  if (!data || data.length === 0) {
    return (
      <div className="chart-wrap--sm" style={{ display: 'grid', placeItems: 'center' }}>
        <p className="small muted" style={{ textAlign: 'center', maxWidth: 300 }}>
          Run an authentication test to start plotting the confidence trend.
        </p>
      </div>
    );
  }

  return (
    <div className="chart-wrap--sm" style={{ width: '100%' }}>
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data} margin={{ top: 8, right: 14, left: -18, bottom: 0 }}>
          <CartesianGrid stroke={CHART.grid} vertical={false} />
          <XAxis
            dataKey="label"
            tick={{ fontSize: 11, fill: CHART.muted }}
            tickLine={false}
            axisLine={{ stroke: CHART.axis }}
          />
          <YAxis
            domain={[0, 100]}
            ticks={[0, 40, 70, 100]}
            tick={{ fontSize: 11, fill: CHART.muted }}
            tickLine={false}
            axisLine={false}
            width={46}
          />
          <Tooltip content={<ChartTooltip labelPrefix="Test " />} cursor={{ stroke: CHART.axis }} />

          <ReferenceLine y={70} stroke={CHART.good} strokeDasharray="4 4" strokeWidth={1.4} />
          <ReferenceLine y={40} stroke={CHART.critical} strokeDasharray="4 4" strokeWidth={1.4} />

          <Line
            type="monotone"
            dataKey="confidence"
            name="Confidence score"
            stroke={CHART.series1}
            strokeWidth={2}
            dot={{ r: 3.5, strokeWidth: 2, stroke: '#fff', fill: CHART.series1 }}
            activeDot={{ r: 5, strokeWidth: 2, stroke: '#fff' }}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
