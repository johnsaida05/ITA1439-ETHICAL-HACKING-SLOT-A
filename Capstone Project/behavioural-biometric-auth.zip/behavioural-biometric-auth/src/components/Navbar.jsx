import { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';

import { useApp } from '../context/AppContext';
import StatusBadge from './StatusBadge';
import { IconLogout, IconRefresh } from './Icons';
import { DEMO_CREDENTIALS } from '../data/constants';

const PAGE_META = {
  '/dashboard': { title: 'Authentication Dashboard', crumb: 'Module 3 - Dashboard & Security Alerts' },
  '/capture': { title: 'Behavioural Data Capture', crumb: 'Module 1 - Data Capture' },
  '/authentication': { title: 'AI-Based User Authentication', crumb: 'Module 2 - Simulated AI/ML Authentication' },
  '/alerts': { title: 'Security Alerts', crumb: 'Module 3 - Alerts & Investigation' },
  '/profile': { title: 'User Profile', crumb: 'Behaviour profile enrollment' },
  '/about': { title: 'About This Project', crumb: 'Architecture, modules and algorithm' },
};

export default function Navbar() {
  const { pathname } = useLocation();
  const { monitoring, lastSession, profile, logout, resetDemo } = useApp();
  const [confirming, setConfirming] = useState(false);

  /* The reset button asks for a second click instead of opening a browser
     dialog - a modal would freeze a live presentation. */
  useEffect(() => {
    if (!confirming) return undefined;
    const t = window.setTimeout(() => setConfirming(false), 4000);
    return () => window.clearTimeout(t);
  }, [confirming]);

  const meta = PAGE_META[pathname] || { title: 'Dashboard', crumb: 'Prototype' };
  const username = profile?.username || DEMO_CREDENTIALS.username;
  const initials = username.slice(0, 2).toUpperCase();

  const handleReset = () => {
    if (!confirming) {
      setConfirming(true);
      return;
    }
    resetDemo();
    setConfirming(false);
  };

  return (
    <header className="navbar">
      <div>
        <h2 className="navbar__heading">{meta.title}</h2>
        <p className="navbar__crumb">{meta.crumb}</p>
      </div>

      <div className="navbar__spacer" />

      <div className="navbar__right">
        <StatusBadge tone={monitoring ? 'good' : 'neutral'} pulse={monitoring}>
          {monitoring ? 'Monitoring active' : 'Monitoring idle'}
        </StatusBadge>

        {lastSession && <StatusBadge tone={lastSession.tone}>{lastSession.status}</StatusBadge>}

        <button
          type="button"
          className={`btn btn--sm ${confirming ? 'btn--danger' : ''}`}
          onClick={handleReset}
          title="Clear the behaviour profile, sessions and alerts from localStorage"
        >
          <IconRefresh size={14} /> {confirming ? 'Click again to reset' : 'Reset demo'}
        </button>

        <div className="navbar__user">
          <span className="avatar">{initials}</span>
          <div>
            <div className="navbar__username">{username}</div>
            <div className="navbar__role">Demo user</div>
          </div>
          <button type="button" className="btn btn--sm" onClick={logout} title="Log out of the demo">
            <IconLogout size={14} />
          </button>
        </div>
      </div>
    </header>
  );
}
