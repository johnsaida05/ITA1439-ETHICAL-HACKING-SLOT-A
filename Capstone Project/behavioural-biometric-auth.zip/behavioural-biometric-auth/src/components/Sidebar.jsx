import { NavLink } from 'react-router-dom';

import { APP_VERSION } from '../data/constants';
import { useApp } from '../context/AppContext';
import {
  IconActivity,
  IconAlert,
  IconBook,
  IconCpu,
  IconDashboard,
  IconShieldCheck,
  IconUser,
} from './Icons';

const NAV_ITEMS = [
  { to: '/dashboard', label: 'Dashboard', Icon: IconDashboard },
  { to: '/capture', label: 'Behaviour Capture', Icon: IconActivity },
  { to: '/authentication', label: 'AI Authentication', Icon: IconCpu },
  { to: '/alerts', label: 'Security Alerts', Icon: IconAlert, badgeKey: 'alerts' },
  { to: '/profile', label: 'User Profile', Icon: IconUser },
  { to: '/about', label: 'About Project', Icon: IconBook },
];

export default function Sidebar() {
  const { openAlerts } = useApp();

  return (
    <aside className="sidebar">
      <div className="sidebar__brand">
        <span className="sidebar__logo">
          <IconShieldCheck size={20} />
        </span>
        <div>
          <div className="sidebar__title">Behavioural Biometric Authentication</div>
          <div className="sidebar__subtitle">using AI &middot; prototype</div>
        </div>
      </div>

      <div className="sidebar__section">Modules</div>

      <nav className="sidebar__nav">
        {NAV_ITEMS.map(({ to, label, Icon, badgeKey }) => (
          <NavLink
            key={to}
            to={to}
            className={({ isActive }) => `navlink ${isActive ? 'is-active' : ''}`}
          >
            <Icon size={17} />
            <span className="navlink__text">{label}</span>
            {badgeKey === 'alerts' && openAlerts.length > 0 && (
              <span className="navlink__badge">{openAlerts.length}</span>
            )}
          </NavLink>
        ))}
      </nav>

      <div className="sidebar__footer">
        Capstone project demo
        <br />
        v{APP_VERSION}
        <br />
        Simulated AI - no real biometrics
      </div>
    </aside>
  );
}
