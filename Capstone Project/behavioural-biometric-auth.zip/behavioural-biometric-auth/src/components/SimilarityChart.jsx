import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  LabelList,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';

import ChartTooltip from './ChartTooltip';
import { CHART } from '../utils/chartUtils';

/**
 * SimilarityChart - per-feature match against the stored profile (Module 2).
 *
 * One measure, so one colour family. Bars that fall below the 70 % low-risk
 * bar are tinted with the reserved status colours and also carry a direct
 * value label, so the weak features are readable without relying on hue.
 */
export default function SimilarityChart({ breakdown = [] }) {
  if (!breakdown || breakdown.length === 0) {
    return (
      <div className="chart-wrap" style={{ display: 'grid', placeItems: 'center' }}>
        <p className="small muted">Run an authentication test to see the per-feature match.</p>
      </div>
    );
  }

  const data = breakdown.map((b) => ({
    name: b.short,
    full: b.label,
    match: b.similarityPct,
    weight: b.weight,
  }));

  const colorFor = (v) => (v >= 70 ? CHART.series1 : v >= 40 ? CHART.warning : CHART.critical);

  return (
    <div style={{ width: '100%', height: 250 }}>
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} layout="vertical" margin={{ top: 4, right: 42, left: 6, bottom: 4 }} barCategoryGap={6}>
          <CartesianGrid stroke={CHART.grid} horizontal={false} />
          <XAxis
            type="number"
            domain={[0, 100]}
            ticks={[0, 25, 50, 75, 100]}
            tick={{ fontSize: 11, fill: CHART.muted }}
            tickLine={false}
            axisLine={{ stroke: CHART.axis }}
            unit="%"
          />
          <YAxis
            type="category"
            dataKey="name"
            tick={{ fontSize: 11.5, fill: CHART.muted }}
            tickLine={false}
            axisLine={false}
            width={96}
          />
          <Tooltip content={<ChartTooltip suffix="%" />} cursor={{ fill: 'rgba(42,120,214,0.06)' }} />

          <Bar dataKey="match" name="Feature match" radius={[0, 4, 4, 0]} maxBarSize={18}>
            {data.map((d) => (
              <Cell key={d.name} fill={colorFor(d.match)} />
            ))}
            <LabelList
              dataKey="match"
              position="right"
              formatter={(v) => `${v}%`}
              style={{ fontSize: 11, fill: 'var(--text-secondary)', fontWeight: 600 }}
            />
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
