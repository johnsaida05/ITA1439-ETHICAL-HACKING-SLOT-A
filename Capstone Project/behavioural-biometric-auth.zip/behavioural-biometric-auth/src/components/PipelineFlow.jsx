import { PIPELINE_STAGES } from '../data/constants';
import { IconArrowRight, IconCheck } from './Icons';

/**
 * PipelineFlow - the system architecture strip.
 *
 * Behavioural Data -> Pre-processing & Feature Extraction -> AI/ML Model
 *   -> Behaviour Comparison -> Risk / Confidence Score
 *
 * `activeIndex` highlights the stage currently running; stages before it are
 * marked done. Pass `completed` to light up the whole chain.
 */
export default function PipelineFlow({ activeIndex = -1, completed = false, compact = false }) {
  return (
    <div className="pipeline">
      {PIPELINE_STAGES.map((stage, i) => {
        const isDone = completed || (activeIndex > -1 && i < activeIndex);
        const isActive = !completed && i === activeIndex;

        return (
          <div key={stage.id} style={{ display: 'contents' }}>
            <div className={`pipeline__stage ${isActive ? 'is-active' : ''} ${isDone ? 'is-done' : ''}`}>
              <span className="pipeline__step">
                {isDone ? (
                  <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}>
                    <IconCheck size={11} /> {stage.step}
                  </span>
                ) : (
                  stage.step
                )}
              </span>
              <span className="pipeline__name">{stage.name}</span>
              {!compact && <span className="pipeline__meta">{stage.meta}</span>}
            </div>

            {i < PIPELINE_STAGES.length - 1 && (
              <div className="pipeline__arrow" aria-hidden="true">
                <IconArrowRight size={16} />
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}
