import { IconInfo, IconAlert } from './Icons';

/**
 * DemoBanner - the honesty notice.
 * Every module shows one of these so nobody watching the demo mistakes the
 * prototype for a real biometric security product.
 */
export default function DemoBanner({ children, tone = 'info' }) {
  const Cmp = tone === 'warning' ? IconAlert : IconInfo;
  return (
    <div className={`demo-banner ${tone === 'warning' ? 'demo-banner--warning' : ''}`}>
      <span style={{ flex: '0 0 16px', marginTop: 1 }}>
        <Cmp size={16} />
      </span>
      <p>{children}</p>
    </div>
  );
}
