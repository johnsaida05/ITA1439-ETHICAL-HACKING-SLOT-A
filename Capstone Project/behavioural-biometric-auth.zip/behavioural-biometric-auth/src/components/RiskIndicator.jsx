import { IconShieldCheck, IconAlert, IconShield } from './Icons';
import { getRiskLevel } from '../utils/riskUtils';

/**
 * RiskIndicator - risk level + authentication status.
 * Status is always carried by an icon AND a text label, never colour alone.
 */
export default function RiskIndicator({ score = null, showStatus = true, showMessage = true }) {
  const risk = getRiskLevel(Number.isFinite(score) ? score : null);

  const IconCmp =
    risk.tone === 'good' ? IconShieldCheck : risk.tone === 'critical' ? IconAlert : IconShield;

  return (
    <div className="risk">
      <div className="risk__head">
        <span className={`risk__icon risk__icon--${risk.tone === 'neutral' ? 'warning' : risk.tone}`}>
          <IconCmp size={20} />
        </span>
        <div>
          <div className="risk__label">{risk.riskLabel}</div>
          {showStatus && <div className="risk__sub">Authentication status: {risk.status}</div>}
        </div>
      </div>

      <div className="risk__scale" aria-hidden="true">
        {[1, 2, 3].map((seg) => (
          <span
            key={seg}
            className={`risk__seg ${seg <= risk.segments ? `is-on--${risk.tone}` : ''}`}
          />
        ))}
      </div>

      {showMessage && <p className="small muted">{risk.message}</p>}
    </div>
  );
}
