import { describeArc, polarPoint, CHART } from '../utils/chartUtils';
import { getRiskLevel } from '../utils/riskUtils';

/**
 * ConfidenceScore - the headline 0-100 gauge (Module 2 output, Module 3 display).
 *
 * The faint track behind the needle is split into the three threshold bands,
 * so the gauge itself explains the 40 / 70 cut-offs during the demo.
 * A hero number, not a chart: no tooltip layer needed.
 */

const CX = 100;
const CY = 104;
const R = 78;

const BANDS = [
  { from: 0, to: 39, color: CHART.critical, label: '0-39 High' },
  { from: 40, to: 69, color: CHART.warning, label: '40-69 Medium' },
  { from: 70, to: 100, color: CHART.good, label: '70-100 Low' },
];

export default function ConfidenceScore({ score = null, caption, showLegend = true }) {
  const hasScore = Number.isFinite(score);
  const value = hasScore ? Math.max(0, Math.min(100, score)) : 0;
  const risk = getRiskLevel(hasScore ? value : null);

  const strokeColor = hasScore
    ? { good: CHART.good, warning: CHART.warning, critical: CHART.critical }[risk.tone]
    : CHART.axis;

  const tick = (at) => {
    const outer = polarPoint(CX, CY, R + 11, at);
    const inner = polarPoint(CX, CY, R - 11, at);
    return <line key={at} x1={inner.x} y1={inner.y} x2={outer.x} y2={outer.y} stroke={CHART.axis} strokeWidth="1.5" />;
  };

  return (
    <div className="gauge">
      <svg className="gauge__svg" viewBox="0 0 200 132" role="img" aria-label={`Confidence score ${hasScore ? value : 'not evaluated'} out of 100`}>
        {/* threshold bands (recessive track) */}
        {BANDS.map((b) => (
          <path
            key={b.label}
            d={describeArc(CX, CY, R, b.from, b.to)}
            fill="none"
            stroke={b.color}
            strokeWidth="14"
            strokeLinecap="butt"
            opacity="0.16"
          />
        ))}

        {/* threshold ticks at 40 and 70 */}
        {[40, 70].map(tick)}

        {/* the score arc */}
        <path
          className="gauge__arc"
          d={describeArc(CX, CY, R, 0, 100)}
          fill="none"
          stroke={strokeColor}
          strokeWidth="14"
          strokeLinecap="round"
          pathLength="100"
          strokeDasharray="100"
          strokeDashoffset={100 - value}
          opacity={hasScore ? 1 : 0.25}
        />

        {/* end caps */}
        <text x="16" y="126" textAnchor="middle" fontSize="10" fill={CHART.muted}>0</text>
        <text x="184" y="126" textAnchor="middle" fontSize="10" fill={CHART.muted}>100</text>

        <text x={CX} y={CY - 16} textAnchor="middle" className="gauge__value" fill="var(--text-primary)">
          {hasScore ? value : '--'}
        </text>
        <text x={CX} y={CY + 4} textAnchor="middle" className="gauge__value-sub" fill="var(--text-muted)">
          / 100
        </text>
      </svg>

      <p className="gauge__caption">{caption || (hasScore ? `${risk.riskLabel} - ${risk.status}` : 'No session evaluated yet')}</p>

      {showLegend && (
        <div className="gauge__legend">
          {BANDS.map((b) => (
            <span key={b.label}>
              <i className="dot" style={{ background: b.color }} />
              {b.label}
            </span>
          ))}
        </div>
      )}
    </div>
  );
}
