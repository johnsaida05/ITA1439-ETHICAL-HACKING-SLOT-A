import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';

import ChartTooltip from './ChartTooltip';
import { CHART } from '../utils/chartUtils';

/**
 * ActivityChart - the Live Activity Monitor (Module 3).
 * Two series on ONE y-axis (both are "events in that second"), so the shapes
 * are directly comparable. Legend is always present; no number on every point.
 */
export default function ActivityChart({ data = [], height = 'chart-wrap' }) {
  if (!data || data.length === 0) {
    return (
      <div className={height} style={{ display: 'grid', placeItems: 'center' }}>
        <p className="small muted" style={{ textAlign: 'center', maxWidth: 320 }}>
          No activity recorded yet. Start behaviour monitoring on the
          <strong> Behaviour Capture </strong>
          page and the live event stream will appear here.
        </p>
      </div>
    );
  }

  return (
    <>
      <div className="chart-legend">
        <span>
          <i style={{ background: CHART.series1 }} />
          Mouse events / second
        </span>
        <span>
          <i style={{ background: CHART.series2 }} />
          Key events / second
        </span>
      </div>

      <div className={height}>
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data} margin={{ top: 6, right: 10, left: -18, bottom: 0 }}>
            <defs>
              <linearGradient id="fillMouse" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={CHART.series1} stopOpacity={0.28} />
                <stop offset="100%" stopColor={CHART.series1} stopOpacity={0.02} />
              </linearGradient>
              <linearGradient id="fillKeys" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={CHART.series2} stopOpacity={0.26} />
                <stop offset="100%" stopColor={CHART.series2} stopOpacity={0.02} />
              </linearGradient>
            </defs>

            <CartesianGrid stroke={CHART.grid} vertical={false} />
            <XAxis
              dataKey="label"
              tick={{ fontSize: 11, fill: CHART.muted }}
              tickLine={false}
              axisLine={{ stroke: CHART.axis }}
              interval="preserveStartEnd"
              minTickGap={24}
            />
            <YAxis
              tick={{ fontSize: 11, fill: CHART.muted }}
              tickLine={false}
              axisLine={false}
              width={46}
              allowDecimals={false}
            />
            <Tooltip
              content={<ChartTooltip labelPrefix="Elapsed " />}
              cursor={{ stroke: CHART.axis, strokeWidth: 1 }}
            />

            <Area
              type="monotone"
              dataKey="mouse"
              name="Mouse events"
              stroke={CHART.series1}
              strokeWidth={2}
              fill="url(#fillMouse)"
              dot={false}
              activeDot={{ r: 4, strokeWidth: 2, stroke: '#fff' }}
            />
            <Area
              type="monotone"
              dataKey="keyboard"
              name="Key events"
              stroke={CHART.series2}
              strokeWidth={2}
              fill="url(#fillKeys)"
              dot={false}
              activeDot={{ r: 4, strokeWidth: 2, stroke: '#fff' }}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </>
  );
}
