/** Shared Recharts tooltip body - text stays in ink colours, the swatch carries identity. */
export default function ChartTooltip({ active, payload, label, labelPrefix = '', suffix = '' }) {
  if (!active || !payload || payload.length === 0) return null;

  return (
    <div className="chart-tooltip">
      <div className="chart-tooltip__label">
        {labelPrefix}
        {label}
      </div>
      {payload.map((entry) => (
        <div className="chart-tooltip__row" key={entry.dataKey}>
          <i
            style={{
              width: 9,
              height: 9,
              borderRadius: 3,
              background: entry.color,
              display: 'inline-block',
              flex: '0 0 9px',
            }}
          />
          <span>{entry.name}</span>
          <span className="chart-tooltip__val">
            {typeof entry.value === 'number' ? entry.value.toLocaleString() : entry.value}
            {suffix}
          </span>
        </div>
      ))}
    </div>
  );
}
