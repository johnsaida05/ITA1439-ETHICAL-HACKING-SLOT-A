import { Icon } from './Icons';
import { timeAgo, formatTime } from '../utils/formatters';

/** ActivityList - the "Recent Activities" feed (Module 3). */
export default function ActivityList({ activities = [], limit = 8 }) {
  if (!activities || activities.length === 0) {
    return <p className="empty">No activity recorded yet.</p>;
  }

  const toneClass = (tone) =>
    ({ good: 'list__icon--good', warning: 'list__icon--warning', critical: 'list__icon--critical', info: 'list__icon--info' }[tone] || '');

  return (
    <div className="list">
      {activities.slice(0, limit).map((a) => (
        <div className="list__item" key={a.id}>
          <span className={`list__icon ${toneClass(a.tone)}`}>
            <Icon name={a.icon} size={15} />
          </span>
          <div style={{ minWidth: 0 }}>
            <div className="list__title">{a.title}</div>
            <div className="list__meta">{a.detail}</div>
          </div>
          <div className="list__right">
            <div className="small muted nowrap">{timeAgo(a.timestamp)}</div>
            <div className="small muted nowrap mono">{formatTime(a.timestamp)}</div>
          </div>
        </div>
      ))}
    </div>
  );
}
