import { formatNumber } from '../utils/formatters';
import StatusBadge from './StatusBadge';

/**
 * BehaviorDataTable - the behaviour comparison table (Module 2, stage 4).
 *
 * variant = 'full'      profile vs current vs deviation vs match vs weight
 * variant = 'baseline'  just the enrolled profile baseline + tolerance
 * variant = 'live'      profile vs live captured value (no model scores)
 *
 * It doubles as the accessible table view for SimilarityChart.
 */
export default function BehaviorDataTable({ rows = [], variant = 'full' }) {
  if (!rows || rows.length === 0) {
    return <p className="small muted" style={{ padding: '14px 16px' }}>No behavioural data available yet.</p>;
  }

  const showCurrent = variant !== 'baseline';
  const showModel = variant === 'full';

  const tone = (pct) => (pct >= 70 ? 'good' : pct >= 40 ? 'warning' : 'critical');

  return (
    <div className="table-wrap">
      <table className="data">
        <thead>
          <tr>
            <th>Feature</th>
            <th>Profile baseline</th>
            <th>Tolerance (+/-)</th>
            {showCurrent && <th>Current session</th>}
            {showCurrent && <th>Deviation</th>}
            {showModel && <th>Feature match</th>}
            {showModel && <th>Weight</th>}
            {showModel && <th>Contribution</th>}
          </tr>
        </thead>
        <tbody>
          {rows.map((r) => (
            <tr key={r.key}>
              <td>
                <div className="feature-name">{r.label}</div>
                <div className="sub">{r.group}</div>
              </td>
              <td className="num">
                {formatNumber(r.baseline, r.decimals)} <span className="sub">{r.unit}</span>
              </td>
              <td className="num sub">
                {formatNumber(r.tolerance, 0)} {r.unit}
              </td>

              {showCurrent && (
                <td className="num">
                  {formatNumber(r.current, r.decimals)} <span className="sub">{r.unit}</span>
                </td>
              )}

              {showCurrent && (
                <td className="num">
                  <span style={{ color: r.withinTolerance ? 'var(--text-secondary)' : 'var(--critical-text)' }}>
                    {r.deviation > 0 ? '+' : ''}
                    {formatNumber(r.deviation, r.decimals)}
                  </span>
                  <div className="sub">{r.withinTolerance ? 'within tolerance' : 'outside tolerance'}</div>
                </td>
              )}

              {showModel && (
                <td>
                  <div className="row" style={{ gap: 8, flexWrap: 'nowrap' }}>
                    <div className="bar" style={{ width: 70, flex: '0 0 70px' }}>
                      <div
                        className={`bar__fill bar__fill--${tone(r.similarityPct)}`}
                        style={{ width: `${r.similarityPct}%` }}
                      />
                    </div>
                    <span className="num" style={{ fontWeight: 600 }}>{r.similarityPct}%</span>
                  </div>
                </td>
              )}

              {showModel && <td className="num sub">{r.weight.toFixed(2)}</td>}
              {showModel && (
                <td className="num">
                  <StatusBadge tone={tone(r.similarityPct)}>{r.contribution.toFixed(1)} pts</StatusBadge>
                </td>
              )}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
