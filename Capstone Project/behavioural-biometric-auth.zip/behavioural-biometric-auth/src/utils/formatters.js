/** Small formatting + math helpers shared across the app. */

export function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value));
}

export function round(value, decimals = 0) {
  const p = 10 ** decimals;
  return Math.round(value * p) / p;
}

/** Random float in [min, max). */
export function randomBetween(min, max) {
  return min + Math.random() * (max - min);
}

/** Randomly returns +1 or -1 - used to drift a feature above or below baseline. */
export function randomSign() {
  return Math.random() < 0.5 ? -1 : 1;
}

export function formatNumber(value, decimals = 0) {
  if (value === null || value === undefined || Number.isNaN(value)) return '--';
  return round(value, decimals).toFixed(decimals);
}

export function formatPercent(fraction, decimals = 0) {
  if (fraction === null || fraction === undefined || Number.isNaN(fraction)) return '--';
  return `${round(fraction * 100, decimals).toFixed(decimals)}%`;
}

/** Seconds -> "m:ss" (session duration display). */
export function formatDuration(totalSeconds) {
  const s = Math.max(0, Math.floor(totalSeconds || 0));
  const m = Math.floor(s / 60);
  const rem = s % 60;
  return `${m}:${String(rem).padStart(2, '0')}`;
}

export function formatTime(isoString) {
  if (!isoString) return '--';
  const d = new Date(isoString);
  if (Number.isNaN(d.getTime())) return '--';
  return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
}

export function formatDate(isoString) {
  if (!isoString) return '--';
  const d = new Date(isoString);
  if (Number.isNaN(d.getTime())) return '--';
  return d.toLocaleDateString([], { day: '2-digit', month: 'short', year: 'numeric' });
}

export function formatDateTime(isoString) {
  if (!isoString) return '--';
  return `${formatDate(isoString)}, ${formatTime(isoString)}`;
}

/** "4 min ago" style relative label for activity + alert rows. */
export function timeAgo(isoString) {
  if (!isoString) return '--';
  const diffMs = Date.now() - new Date(isoString).getTime();
  const mins = Math.floor(diffMs / 60000);
  if (mins < 1) return 'just now';
  if (mins === 1) return '1 min ago';
  if (mins < 60) return `${mins} min ago`;
  const hours = Math.floor(mins / 60);
  if (hours === 1) return '1 hour ago';
  if (hours < 24) return `${hours} hours ago`;
  const days = Math.floor(hours / 24);
  return days === 1 ? '1 day ago' : `${days} days ago`;
}

/** Short pseudo-random id. Fine for a front-end demo. */
export function makeId(prefix = 'id') {
  return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;
}

/** Reads the current browser/OS as the "registered device" string. */
export function detectDevice() {
  if (typeof navigator === 'undefined') return 'Unknown device';
  const ua = navigator.userAgent;
  const os = /Windows NT 10/.test(ua)
    ? 'Windows 10/11'
    : /Windows/.test(ua)
      ? 'Windows'
      : /Mac OS X/.test(ua)
        ? 'macOS'
        : /Android/.test(ua)
          ? 'Android'
          : /Linux/.test(ua)
            ? 'Linux'
            : 'Unknown OS';
  const browser = /Edg\//.test(ua)
    ? 'Edge'
    : /Chrome\//.test(ua)
      ? 'Chrome'
      : /Firefox\//.test(ua)
        ? 'Firefox'
        : /Safari\//.test(ua)
          ? 'Safari'
          : 'Browser';
  return `${os} - ${browser}`;
}
