/** Geometry helpers for the hand-built SVG confidence gauge. */

/**
 * Converts a 0-100 score into a point on a semicircular arc.
 * Score 0 sits at the far left (180 deg), score 100 at the far right (0 deg).
 */
export function polarPoint(cx, cy, radius, score) {
  const angleDeg = 180 - (score / 100) * 180;
  const rad = (angleDeg * Math.PI) / 180;
  return {
    x: cx + radius * Math.cos(rad),
    y: cy - radius * Math.sin(rad),
  };
}

/** SVG path description for the arc between two scores. */
export function describeArc(cx, cy, radius, fromScore, toScore) {
  const start = polarPoint(cx, cy, radius, fromScore);
  const end = polarPoint(cx, cy, radius, toScore);
  const largeArc = Math.abs(toScore - fromScore) > 50 ? 1 : 0;
  return `M ${start.x.toFixed(2)} ${start.y.toFixed(2)} A ${radius} ${radius} 0 ${largeArc} 1 ${end.x.toFixed(2)} ${end.y.toFixed(2)}`;
}

/** Chart palette - kept in one place so every chart stays on the same system. */
export const CHART = {
  series1: '#2a78d6', // blue  - mouse / confidence
  series2: '#eb6834', // orange - keyboard
  grid: '#e4e8ef',
  axis: '#c7d0de',
  muted: '#7b8696',
  good: '#0ca30c',
  warning: '#fab219',
  critical: '#d03b3b',
};
