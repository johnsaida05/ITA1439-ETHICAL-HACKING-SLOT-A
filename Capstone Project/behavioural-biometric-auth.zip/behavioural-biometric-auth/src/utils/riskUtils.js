import { THRESHOLDS } from '../data/constants';

/**
 * Maps a 0-100 confidence score to a risk level + authentication status.
 * This is the single place the threshold rules live, so Module 2 and
 * Module 3 can never disagree with each other.
 */
export function getRiskLevel(score) {
  if (score === null || score === undefined || Number.isNaN(score)) {
    return {
      level: 'unknown',
      riskLabel: 'Not evaluated',
      status: 'Not Authenticated',
      statusShort: 'Not evaluated',
      tone: 'neutral',
      segments: 0,
      message: 'Run an authentication test to evaluate this session.',
    };
  }

  if (score >= THRESHOLDS.LOW_RISK_MIN) {
    return {
      level: 'low',
      riskLabel: 'Low Risk',
      status: 'Authenticated',
      statusShort: 'Authenticated',
      tone: 'good',
      segments: 3,
      message: 'Session behaviour matches the stored profile. Access granted.',
    };
  }

  if (score >= THRESHOLDS.MEDIUM_RISK_MIN) {
    return {
      level: 'medium',
      riskLabel: 'Medium Risk',
      status: 'Verification Required',
      statusShort: 'Verification Required',
      tone: 'warning',
      segments: 2,
      message: 'Partial match. A second authentication factor would be requested.',
    };
  }

  return {
    level: 'high',
    riskLabel: 'High Risk',
    status: 'Suspicious Activity',
    statusShort: 'Suspicious Activity',
    tone: 'critical',
    segments: 1,
    message: 'Behaviour does not match the stored profile. Session flagged.',
  };
}

/** Human-readable threshold table, reused by several pages. */
export const THRESHOLD_ROWS = [
  { range: '70 - 100', risk: 'Low Risk', status: 'Authenticated', tone: 'good' },
  { range: '40 - 69', risk: 'Medium Risk', status: 'Verification Required', tone: 'warning' },
  { range: '0 - 39', risk: 'High Risk', status: 'Suspicious Activity', tone: 'critical' },
];

/** CSS colour variable for a tone, used by the SVG gauge and charts. */
export function toneColor(tone) {
  switch (tone) {
    case 'good':
      return 'var(--good)';
    case 'warning':
      return 'var(--warning)';
    case 'critical':
      return 'var(--critical)';
    default:
      return 'var(--text-muted)';
  }
}
