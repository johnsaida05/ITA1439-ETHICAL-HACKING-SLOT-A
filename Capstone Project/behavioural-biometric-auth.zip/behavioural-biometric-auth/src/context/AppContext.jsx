/**
 * AppContext - the single source of truth for the whole demo.
 *
 * It wires the three modules together:
 *   Module 1  live/simulated behaviour capture  (monitoring, rawMetrics, timeline)
 *   Module 2  simulated AI authentication       (runAuthTest, sessions)
 *   Module 3  dashboard + security alerts       (alerts, activities)
 *
 * Everything persists through localStorage via storageService, so a reload
 * during the presentation does not lose the enrolled profile or the alert log.
 */

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';

import { DEMO_CREDENTIALS } from '../data/constants';
import { SAMPLE_ACTIVITIES, FOLLOW_UP_ACTIVITIES } from '../data/sampleActivities';
import {
  buildProfile,
  deriveFeatures,
  emptyRawMetrics,
  generateSessionFeatures,
  hasEnoughData,
  hydrateProfile,
  rawFromFeatures,
  simulateOneSecond,
} from '../services/behaviourService';
import { buildAlertForSession, evaluateSession } from '../services/authService';
import * as storage from '../services/storageService';
import { makeId } from '../utils/formatters';

const AppContext = createContext(null);

const TIMELINE_LENGTH = 30;
const SCROLL_DEBOUNCE_MS = 80;

/** Seed activities get real timestamps relative to "now" on first load. */
function seedActivities() {
  const now = Date.now();
  return SAMPLE_ACTIVITIES.map((a) => ({
    id: a.id,
    title: a.title,
    detail: a.detail,
    tone: a.tone,
    icon: a.icon,
    timestamp: new Date(now - a.minutesAgo * 60000).toISOString(),
  })).reverse(); // newest first
}

export function AppProvider({ children }) {
  /* ---------------- persisted state ---------------- */
  const [loggedIn, setLoggedIn] = useState(() => storage.loadLoggedIn());
  const [profile, setProfile] = useState(() => hydrateProfile(storage.loadProfile()));
  const [sessions, setSessions] = useState(() => storage.loadSessions());
  const [alerts, setAlerts] = useState(() => storage.loadAlerts());
  const [activities, setActivities] = useState(() => storage.loadActivities() || seedActivities());

  /* ---------------- live capture state ---------------- */
  const [monitoring, setMonitoring] = useState(false);
  const [autoSimulate, setAutoSimulate] = useState(true);
  const [rawMetrics, setRawMetrics] = useState(() => emptyRawMetrics());
  const [timeline, setTimeline] = useState([]);

  /* ---------------- refs used by the event listeners ---------------- */
  const rawRef = useRef(emptyRawMetrics());
  const prevCountsRef = useRef({ keyPresses: 0, mouseMoves: 0, clicks: 0, scrolls: 0 });
  const keyDownAtRef = useRef({});
  const lastKeyDownRef = useRef(null);
  const lastMousePosRef = useRef(null);
  const lastScrollAtRef = useRef(0);
  const tickRef = useRef(0);

  /* ---------------- persistence effects ---------------- */
  useEffect(() => storage.saveLoggedIn(loggedIn), [loggedIn]);
  useEffect(() => {
    if (profile) storage.saveProfile(profile);
  }, [profile]);
  useEffect(() => storage.saveSessions(sessions), [sessions]);
  useEffect(() => storage.saveAlerts(alerts), [alerts]);
  useEffect(() => storage.saveActivities(activities), [activities]);

  /* ---------------- activity feed helper ---------------- */
  const addActivity = useCallback((activity) => {
    setActivities((prev) =>
      [
        {
          id: makeId('ACT'),
          timestamp: new Date().toISOString(),
          tone: 'info',
          icon: 'info',
          ...activity,
        },
        ...prev,
      ].slice(0, 40),
    );
  }, []);

  /* ================================================================
     MODULE 1 - behavioural data capture
     ================================================================ */

  const resetCapture = useCallback(() => {
    rawRef.current = emptyRawMetrics();
    prevCountsRef.current = { keyPresses: 0, mouseMoves: 0, clicks: 0, scrolls: 0 };
    keyDownAtRef.current = {};
    lastKeyDownRef.current = null;
    lastMousePosRef.current = null;
    tickRef.current = 0;
    setRawMetrics(emptyRawMetrics());
    setTimeline([]);
  }, []);

  const startMonitoring = useCallback(() => {
    resetCapture();
    rawRef.current = { ...emptyRawMetrics(), startedAt: new Date().toISOString() };
    setRawMetrics(rawRef.current);
    setMonitoring(true);
    addActivity({
      title: 'Behaviour Monitoring Started',
      detail: 'Module 1 began collecting keystroke, mouse and scroll events',
      tone: 'info',
      icon: 'activity',
    });
  }, [addActivity, resetCapture]);

  const stopMonitoring = useCallback(() => {
    setMonitoring(false);
    addActivity({
      title: 'Behaviour Monitoring Stopped',
      detail: `Captured ${rawRef.current.keyPresses} key events and ${rawRef.current.mouseMoves} mouse events`,
      tone: 'neutral',
      icon: 'activity',
    });
  }, [addActivity]);

  /* -------- real browser event listeners (only while monitoring) -------- */
  useEffect(() => {
    if (!monitoring) return undefined;

    const onKeyDown = (e) => {
      if (e.repeat) return;
      const now = performance.now();
      keyDownAtRef.current[e.code || e.key] = now;
      if (lastKeyDownRef.current !== null) {
        const gap = now - lastKeyDownRef.current;
        if (gap > 10 && gap < 3000) {
          rawRef.current.flightTimeTotalMs += gap;
          rawRef.current.flightTimeSamples += 1;
        }
      }
      lastKeyDownRef.current = now;
      rawRef.current.keyPresses += 1;
      if (e.key && e.key.length === 1) rawRef.current.charsTyped += 1;
    };

    const onKeyUp = (e) => {
      const code = e.code || e.key;
      const downAt = keyDownAtRef.current[code];
      if (downAt) {
        const hold = performance.now() - downAt;
        if (hold > 5 && hold < 2000) {
          rawRef.current.holdTimeTotalMs += hold;
          rawRef.current.holdTimeSamples += 1;
        }
        delete keyDownAtRef.current[code];
      }
    };

    const onMouseMove = (e) => {
      const prev = lastMousePosRef.current;
      if (prev) {
        const dx = e.clientX - prev.x;
        const dy = e.clientY - prev.y;
        rawRef.current.mouseDistancePx += Math.sqrt(dx * dx + dy * dy);
      }
      lastMousePosRef.current = { x: e.clientX, y: e.clientY };
      rawRef.current.mouseMoves += 1;
    };

    const onClick = () => {
      rawRef.current.clicks += 1;
    };

    const onScroll = () => {
      const now = performance.now();
      if (now - lastScrollAtRef.current < SCROLL_DEBOUNCE_MS) return;
      lastScrollAtRef.current = now;
      rawRef.current.scrolls += 1;
    };

    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('click', onClick);
    window.addEventListener('scroll', onScroll, true);
    window.addEventListener('wheel', onScroll, { passive: true });

    return () => {
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('click', onClick);
      window.removeEventListener('scroll', onScroll, true);
      window.removeEventListener('wheel', onScroll);
    };
  }, [monitoring]);

  /* -------- 1 Hz tick: optional simulation + publish to React state -------- */
  useEffect(() => {
    if (!monitoring) return undefined;

    const interval = window.setInterval(() => {
      tickRef.current += 1;

      if (autoSimulate) {
        rawRef.current = simulateOneSecond(rawRef.current, profile, 'genuine');
      }

      const startedAt = rawRef.current.startedAt
        ? new Date(rawRef.current.startedAt).getTime()
        : Date.now();
      rawRef.current.durationSec = Math.max(0, Math.round((Date.now() - startedAt) / 1000));

      const snapshot = { ...rawRef.current };
      setRawMetrics(snapshot);

      const prev = prevCountsRef.current;
      const point = {
        t: tickRef.current,
        label: `${tickRef.current}s`,
        keyboard: Math.max(0, snapshot.keyPresses - prev.keyPresses),
        mouse: Math.max(0, snapshot.mouseMoves - prev.mouseMoves),
        clicks: Math.max(0, snapshot.clicks - prev.clicks),
      };
      prevCountsRef.current = {
        keyPresses: snapshot.keyPresses,
        mouseMoves: snapshot.mouseMoves,
        clicks: snapshot.clicks,
        scrolls: snapshot.scrolls,
      };

      setTimeline((prevTimeline) => [...prevTimeline, point].slice(-TIMELINE_LENGTH));
    }, 1000);

    return () => window.clearInterval(interval);
  }, [monitoring, autoSimulate, profile]);

  const liveFeatures = useMemo(() => deriveFeatures(rawMetrics), [rawMetrics]);
  const captureReady = useMemo(() => hasEnoughData(rawMetrics), [rawMetrics]);

  /* ================================================================
     MODULE 2 - simulated AI authentication
     ================================================================ */

  const recordSession = useCallback(
    (session) => {
      setSessions((prev) => [session, ...prev].slice(0, 40));

      const alert = buildAlertForSession(session);
      if (alert) setAlerts((prev) => [alert, ...prev].slice(0, 40));

      if (session.riskLevel === 'low') {
        addActivity({
          title: 'Login Successful',
          detail: `Authenticated with confidence ${session.confidenceScore}/100`,
          tone: 'good',
          icon: 'login',
        });
        const extra = FOLLOW_UP_ACTIVITIES[Math.floor(Math.random() * FOLLOW_UP_ACTIVITIES.length)];
        addActivity({ ...extra });
      } else if (session.riskLevel === 'medium') {
        addActivity({
          title: 'Verification Required',
          detail: `Confidence ${session.confidenceScore}/100 - step-up verification requested`,
          tone: 'warning',
          icon: 'shield',
        });
      } else {
        addActivity({
          title: 'Suspicious Activity Detected',
          detail: `Confidence ${session.confidenceScore}/100 - session flagged for investigation`,
          tone: 'critical',
          icon: 'alert',
        });
      }

      return session;
    },
    [addActivity],
  );

  /**
   * "Run Authentication Test".
   * Uses the live captured session when enough real events were collected,
   * otherwise falls back to a generated session (and labels it as such).
   */
  const runAuthTest = useCallback(
    (mode = 'auto') => {
      if (!profile) return null;

      const useLive = mode === 'auto' && captureReady;
      const features = useLive
        ? liveFeatures
        : generateSessionFeatures(profile, mode === 'auto' ? 'genuine' : mode);

      const raw = useLive ? { ...rawMetrics } : rawFromFeatures(features, 30);

      const session = evaluateSession(profile, features, {
        source: useLive ? 'live capture' : 'simulated session',
        mode: useLive ? 'live' : mode === 'auto' ? 'genuine' : mode,
        raw,
        durationSec: raw.durationSec,
      });

      return recordSession(session);
    },
    [profile, captureReady, liveFeatures, rawMetrics, recordSession],
  );

  /** "Simulate Suspicious Activity" - forces a low-confidence session. */
  const simulateSuspicious = useCallback(() => {
    if (!profile) return null;
    const features = generateSessionFeatures(profile, 'suspicious');
    const raw = rawFromFeatures(features, 30);
    const session = evaluateSession(profile, features, {
      source: 'simulated session',
      mode: 'suspicious',
      raw,
      durationSec: raw.durationSec,
    });
    return recordSession(session);
  }, [profile, recordSession]);

  /** Middle band, useful for showing the "Verification Required" state. */
  const simulateBorderline = useCallback(() => {
    if (!profile) return null;
    const features = generateSessionFeatures(profile, 'borderline');
    const raw = rawFromFeatures(features, 30);
    const session = evaluateSession(profile, features, {
      source: 'simulated session',
      mode: 'borderline',
      raw,
      durationSec: raw.durationSec,
    });
    return recordSession(session);
  }, [profile, recordSession]);

  /* ================================================================
     Profile management (enrollment)
     ================================================================ */

  const createOrUpdateProfile = useCallback(
    ({ fromLive = false, username } = {}) => {
      const features = fromLive && captureReady ? liveFeatures : null;
      const next = buildProfile({
        username: username || profile?.username || DEMO_CREDENTIALS.username,
        features,
        existing: profile,
      });
      setProfile(next);
      addActivity({
        title: profile ? 'Behaviour Profile Updated' : 'Behaviour Profile Created',
        detail: features
          ? 'Baseline enrolled from the live captured session'
          : 'Baseline enrolled from generated sample behaviour',
        tone: 'good',
        icon: 'user',
      });
      return next;
    },
    [profile, captureReady, liveFeatures, addActivity],
  );

  /* ================================================================
     MODULE 3 - alerts
     ================================================================ */

  const acknowledgeAlert = useCallback((id) => {
    setAlerts((prev) =>
      prev.map((a) =>
        a.id === id
          ? { ...a, acknowledged: true, investigationStatus: 'Reviewed by security team' }
          : a,
      ),
    );
  }, []);

  const clearAlerts = useCallback(() => {
    setAlerts([]);
    addActivity({
      title: 'Security Alerts Cleared',
      detail: 'Alert log emptied by the admin / security team',
      tone: 'neutral',
      icon: 'shield',
    });
  }, [addActivity]);

  /* ================================================================
     Demo reset + login
     ================================================================ */

  const resetDemo = useCallback(() => {
    setMonitoring(false);
    resetCapture();
    storage.clearDemoData({ keepLogin: true });
    setProfile(null);
    setSessions([]);
    setAlerts([]);
    setActivities(seedActivities());
  }, [resetCapture]);

  const login = useCallback(
    (username, password) => {
      const ok =
        username.trim().toLowerCase() === DEMO_CREDENTIALS.username &&
        password === DEMO_CREDENTIALS.password;
      if (ok) {
        setLoggedIn(true);
        addActivity({
          title: 'Login Successful',
          detail: 'Credentials accepted - behavioural layer now active',
          tone: 'good',
          icon: 'login',
        });
      }
      return ok;
    },
    [addActivity],
  );

  const logout = useCallback(() => {
    setMonitoring(false);
    setLoggedIn(false);
    addActivity({ title: 'Logout', detail: 'Session closed by the user', tone: 'neutral', icon: 'logout' });
  }, [addActivity]);

  /* ================================================================
     Derived values used by several pages
     ================================================================ */

  const lastSession = sessions[0] || null;
  const openAlerts = useMemo(() => alerts.filter((a) => !a.acknowledged), [alerts]);

  const confidenceTrend = useMemo(
    () =>
      [...sessions]
        .slice(0, 12)
        .reverse()
        .map((s, i) => ({
          index: i + 1,
          label: `T${i + 1}`,
          confidence: s.confidenceScore,
          similarity: s.similarityScore,
          mode: s.mode,
        })),
    [sessions],
  );

  const value = useMemo(
    () => ({
      // auth / shell
      loggedIn,
      login,
      logout,
      // profile
      profile,
      createOrUpdateProfile,
      // module 1
      monitoring,
      startMonitoring,
      stopMonitoring,
      resetCapture,
      autoSimulate,
      setAutoSimulate,
      rawMetrics,
      liveFeatures,
      captureReady,
      timeline,
      // module 2
      sessions,
      lastSession,
      runAuthTest,
      simulateSuspicious,
      simulateBorderline,
      confidenceTrend,
      // module 3
      alerts,
      openAlerts,
      acknowledgeAlert,
      clearAlerts,
      activities,
      addActivity,
      // demo control
      resetDemo,
    }),
    [
      loggedIn,
      login,
      logout,
      profile,
      createOrUpdateProfile,
      monitoring,
      startMonitoring,
      stopMonitoring,
      resetCapture,
      autoSimulate,
      rawMetrics,
      liveFeatures,
      captureReady,
      timeline,
      sessions,
      lastSession,
      runAuthTest,
      simulateSuspicious,
      simulateBorderline,
      confidenceTrend,
      alerts,
      openAlerts,
      acknowledgeAlert,
      clearAlerts,
      activities,
      addActivity,
      resetDemo,
    ],
  );

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used inside <AppProvider>');
  return ctx;
}

export default AppContext;
