# Behavioural Biometric Authentication using AI

A college capstone project prototype. It demonstrates the concept of behavioural
biometric authentication — identifying a user by **how** they type, move the mouse, click
and scroll — with a **simulated AI/ML scoring engine**, a dashboard UI, and automatic
security alerts.

> **Scope statement.** This is a front-end demonstration only. There is no biometric
> hardware, no trained machine-learning model, no backend and no real attack detection.
> The confidence score comes from a transparent weighted-similarity formula that can be
> recomputed by hand — which is exactly why it is easy to defend in a viva.

---

## 1. Quick start

```bash
# 1. install dependencies
npm install

# 2. run the development server
npm run dev
```

Then open **http://localhost:5173** (Vite prints the exact URL and opens the browser for you).

Other commands:

```bash
npm run build     # production build into dist/
npm run preview   # serve the production build locally
```

Requirements: **Node.js 18 or newer** (tested on Node 22) and npm.

### Sample credentials

| Field | Value |
|---|---|
| Username | `student` |
| Password | `demo123` |

The login check is a plain string comparison in the browser (`src/data/constants.js`).
It exists to frame the story — password first, behaviour second — not to provide security.

---

## 2. Project folder structure

```
behavioural-biometric-auth/
├── index.html                      # Vite entry HTML
├── package.json
├── vite.config.js
├── README.md
└── src/
    ├── main.jsx                    # React root + router + context provider
    ├── App.jsx                     # Login gate, app shell, routes
    │
    ├── components/                 # reusable UI building blocks
    │   ├── ActivityChart.jsx       # live activity area chart (Recharts)
    │   ├── ActivityList.jsx        # "Recent Activities" feed
    │   ├── BehaviorDataTable.jsx   # behaviour comparison table
    │   ├── Card.jsx                # generic panel
    │   ├── ChartTooltip.jsx        # shared chart tooltip
    │   ├── ConfidenceScore.jsx     # hand-built SVG gauge (0–100)
    │   ├── ConfidenceTrendChart.jsx# confidence over recent tests (line)
    │   ├── DemoBanner.jsx          # "this is a simulation" notice
    │   ├── Icons.jsx               # inline SVG icon set
    │   ├── MetricCard.jsx          # one KPI / captured metric
    │   ├── Navbar.jsx              # top bar + reset demo + logout
    │   ├── PipelineFlow.jsx        # 5-stage architecture strip
    │   ├── RiskIndicator.jsx       # risk level + auth status
    │   ├── SecurityAlert.jsx       # alert card + "No Alerts" state
    │   ├── Sidebar.jsx             # left navigation
    │   ├── SimilarityChart.jsx     # per-feature match bar chart
    │   └── StatusBadge.jsx         # coloured status pill
    │
    ├── pages/                      # one file per screen
    │   ├── Login.jsx
    │   ├── Dashboard.jsx           # MODULE 3
    │   ├── BehaviourCapture.jsx    # MODULE 1
    │   ├── AiAuthentication.jsx    # MODULE 2
    │   ├── SecurityAlerts.jsx      # MODULE 3
    │   ├── UserProfile.jsx         # enrollment
    │   └── AboutProject.jsx        # architecture + algorithm reference
    │
    ├── services/                   # all the logic, no JSX
    │   ├── behaviourService.js     # capture → features, session generation
    │   ├── authService.js          # the simulated AI/ML model
    │   └── storageService.js       # the only module touching localStorage
    │
    ├── context/
    │   └── AppContext.jsx          # global state wiring the three modules
    │
    ├── utils/
    │   ├── riskUtils.js            # thresholds → risk level / status
    │   ├── formatters.js           # number, date, duration helpers
    │   └── chartUtils.js           # gauge geometry + chart palette
    │
    ├── data/
    │   ├── constants.js            # features, weights, thresholds, credentials
    │   └── sampleActivities.js     # seed rows for the activity feed
    │
    └── styles/
        └── global.css              # design tokens + all component styles
```

---

## 3. How each module works

### Module 1 — Behavioural Data Capture (`/capture`)

Collects behaviour from **two sources**, both visible in the UI:

1. **Real browser events.** While monitoring is on, `AppContext` attaches listeners for
   `keydown` / `keyup` (dwell and flight times), `mousemove` (path length), `click` and
   `scroll`. Counters live in a `ref` so the page does not re-render on every event; a
   1 Hz timer publishes a snapshot to React state.
2. **An optional simulator.** The **Auto-simulate activity** switch (on by default) adds
   one second of synthetic events per tick, centred on the enrolled baseline. This keeps
   the metrics moving while you talk during a presentation.

Raw counters are then reduced to six numeric features (`deriveFeatures`), rate-normalised
against the session duration so a 10-second and a 60-second sample are comparable:

| Feature | Unit | Group | Weight |
|---|---|---|---|
| Typing speed | WPM | Keystroke dynamics | 0.20 |
| Avg key press duration (dwell) | ms | Keystroke dynamics | 0.18 |
| Avg flight time (key to key) | ms | Keystroke dynamics | 0.14 |
| Mouse movement speed | px/s | Mouse movements | 0.16 |
| Click rate | clicks/min | Click & scroll | 0.16 |
| Scroll rate | scrolls/min | Click & scroll | 0.16 |

The page also shows **Session Information** and an **Application Usage** card. Application
usage is not measurable from a browser tab, so those three rows are fixed sample values,
labelled as such in the UI.

### Module 2 — AI-Based User Authentication (`/authentication`)

Walks visibly through the five pipeline stages, then shows the full comparison:

```
Behavioural Data → Pre-processing & Feature Extraction → AI/ML Model
                 → Behaviour Comparison → Risk / Confidence Score
```

Outputs on screen: the stored **profile baseline**, the **current session** values, the
**deviation**, the **per-feature match**, the **similarity score**, the **confidence
score** and the **risk level**.

Three buttons drive it:

- **Run Authentication Test** — uses the real captured session when Module 1 has collected
  enough events (≥ 5 s, ≥ 12 key events, ≥ 25 mouse events); otherwise generates a
  genuine-user session and says so.
- **Simulate Borderline Session** — forces the medium-risk branch.
- **Simulate Suspicious Activity** — forces the high-risk branch and raises an alert.

### Module 3 — Dashboard & Security Alerts (`/dashboard`, `/alerts`)

- Authentication status, confidence gauge and risk indicator.
- **Live Activity Monitor** — mouse and key events per second.
- **Confidence Score Trend** — recent tests with the 70 and 40 thresholds drawn in.
- **Recent Activities** — login, file access, data update, logout, etc.
- **Security Alerts** — `No Alerts` when healthy; an alert is generated automatically
  whenever a session scores below 70, with an **Admin / Security Team — Investigation**
  queue and an escalation flow table.

---

## 4. How the simulated AI authentication algorithm works

All of it lives in `src/services/authService.js`.

```
INPUT   profile.baseline[i], profile.tolerance[i], session.current[i]

1  normalise   n_i = (x_i - min_i) / (max_i - min_i)          (display only)
2  deviation   d_i = | current_i - baseline_i |
3  similarity  s_i = max(0, 1 - d_i / (2 × tolerance_i))
                     d_i = 0           →  s_i = 1.00   perfect match
                     d_i = tolerance   →  s_i = 0.50   edge of the accepted band
                     d_i ≥ 2×tolerance →  s_i = 0.00   no match
4  confidence  C   = 100 × Σ (w_i × s_i)        with Σ w_i = 1
5  similarity  S   = 100 × mean(s_i)            (unweighted, for comparison)
6  decision    C ≥ 70  →  Low Risk     / Authenticated
               C ≥ 40  →  Medium Risk  / Verification Required
               else    →  High Risk    / Suspicious Activity
```

**Similarity vs confidence.** `S` is the plain average of the six matches; `C` is the
weighted average that drives the decision. Showing both makes the role of the weights
visible — if they diverge, the mismatch is concentrated in a heavily-weighted feature.

**Why this and not a neural network?**

- Every score can be recomputed by hand, so the demo can be explained line by line.
- It needs no training data, which a classroom project cannot collect ethically.
- It is the standard *distance-to-template* baseline that real behavioural-biometric
  papers compare their models against — so the concept demonstrated is genuine even
  though the implementation is deliberately simple.

**What a production system would add:** many enrollment sessions averaged into the
template with per-user standard deviations instead of fixed tolerances; a trained
classifier (one-class SVM, random forest, or an LSTM over keystroke sequences) in place
of step 3; server-side scoring, encrypted templates and continuous re-authentication.

**Session generation.** `generateSessionFeatures` offsets each feature from the baseline
by a multiple of its tolerance, chosen so each demo mode lands reliably in its own band:

| Mode | Offset (× tolerance) | Typical confidence | Risk |
|---|---|---|---|
| genuine | 0.05 – 0.55 | 72 – 97 | Low |
| borderline | 0.70 – 1.20 | 40 – 65 | Medium |
| suspicious | 1.25 – 2.20 | 5 – 30 | High |

---

## 5. Data stored in the browser

Everything persists in `localStorage` — no backend, no network calls.

| Key | Contents |
|---|---|
| `bioauth.profile` | the enrolled behaviour baseline and tolerances |
| `bioauth.sessions` | the last 40 evaluated sessions with their scores |
| `bioauth.alerts` | the security alert log |
| `bioauth.activities` | the recent-activity feed |
| `bioauth.loggedIn` | the demo login flag |

**Reset demo** in the top bar (press it twice to confirm) clears all of it.

---

## 6. Suggested demo script (≈ 5 minutes)

1. Log in with `student` / `demo123`; show the dashboard overview.
2. **User Profile → Create / Update Behaviour Profile.** Explain that this is *enrollment*.
3. **Behaviour Capture → Start Monitoring.** Type in the capture box, move the mouse,
   scroll the scroll box. Point out the live metrics and the activity chart.
4. **AI Authentication → Run Authentication Test.** Walk through the five stages and the
   comparison table; show similarity vs confidence.
5. **Simulate Suspicious Activity.** The score collapses, the gauge turns red, the status
   becomes *Suspicious Activity* and an alert appears.
6. **Security Alerts.** Show the alert detail and the Admin / Security Team queue.
7. Back to the **Dashboard**, then **Reset demo** twice for a clean state.

---

## 7. Technology stack

| Technology | Role |
|---|---|
| React 18 | Component UI, hooks, Context API for state |
| react-router-dom 6 | Client-side routing between the module pages |
| Vite 5 | Dev server and production build |
| Recharts 2 | Area, line and bar charts |
| Plain CSS | Design tokens in `src/styles/global.css` — no UI framework |
| localStorage | Persists profile, sessions, alerts and activities |
| Inline SVG | Icons and the confidence gauge — no icon dependency |

---

## 8. Deliberately out of scope

- No biometric hardware, camera, fingerprint reader or any physical sensor.
- No trained ML model, no training data, no inference server.
- No backend, database or API — the whole app runs in one browser tab.
- No real intrusion detection, network monitoring or attack analysis.
- No surveillance: only this tab, only while monitoring is on, and nothing is transmitted.
